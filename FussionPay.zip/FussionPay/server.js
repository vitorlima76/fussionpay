const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, randomUUID } = require('node:crypto');
const express = require('express');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const QRCode = require('qrcode');
const { statements, db } = require('./src/db');
const {
    SyncPayApiError,
    SyncPayClient,
    buildCashInPayload,
    normalizeSyncPayStatus,
    verifySyncPaySignature
} = require('./src/syncpay');
const {
    hashPassword,
    verifyPassword,
    hashToken,
    createSessionToken,
    isValidEmail
} = require('./src/security');

const app = express();
const host = process.env.HOST
    || (process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1');
const port = Number(process.env.PORT || 5501);
const expectedOrigin = process.env.APP_ORIGIN || `http://${host}:${port}`;
const sessionCookie = 'fussionpay_session';
const sessionDurationMs = 8 * 60 * 60 * 1000;
const panelPath = path.join(__dirname, 'fussionpay_painel.html');
const loginPath = path.join(__dirname, 'public', 'login.html');
const logoPath = path.join(__dirname, 'public', 'fussionpay-logo.png');
const sharkPath = path.join(__dirname, 'public', 'fussionpay-shark.svg');
const failedLogins = new Map();
const deniedAccessAlerts = new Map();
const securityEventSubscribers = new Set();
const securityEventResponses = new Set();
const rateLimitAlertTimes = new Map();
const isProduction = process.env.NODE_ENV === 'production';
const paymentMode = process.env.PAYMENT_MODE || 'disabled';
const syncPayEnabled = paymentMode === 'syncpay_live';

if (!['disabled', 'sandbox', 'syncpay_live'].includes(paymentMode)) {
    throw new Error('PAYMENT_MODE precisa ser disabled, sandbox ou syncpay_live.');
}
if (syncPayEnabled && !isProduction) {
    throw new Error('SyncPay real só pode ser habilitada com NODE_ENV=production.');
}
if (isProduction && paymentMode === 'sandbox') {
    throw new Error('O modo sandbox não pode ser usado em produção.');
}
if (syncPayEnabled && (!process.env.SYNCPAY_CLIENT_ID
    || !process.env.SYNCPAY_CLIENT_SECRET || !process.env.SYNCPAY_WEBHOOK_SECRET)) {
    throw new Error('SyncPay real exige credenciais da API e segredo do webhook configurados.');
}
if (isProduction && (!process.env.APP_ORIGIN || !/^https:\/\/[^/]+$/.test(process.env.APP_ORIGIN))) {
    throw new Error('APP_ORIGIN precisa ser a origem pública HTTPS, sem caminho ou barra final, em produção.');
}
const syncPayClient = syncPayEnabled
    ? new SyncPayClient({
        clientId: process.env.SYNCPAY_CLIENT_ID,
        clientSecret: process.env.SYNCPAY_CLIENT_SECRET
    })
    : null;

if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT precisa ser um número entre 1 e 65535.');
}

app.disable('x-powered-by');
app.use((req, res, next) => {
    res.locals.cspNonce = randomBytes(18).toString('base64');
    next();
});
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            baseUri: ["'self'"],
            connectSrc: ["'self'"],
            fontSrc: ["'self'", 'data:'],
            formAction: ["'self'"],
            frameAncestors: ["'none'"],
            imgSrc: ["'self'", 'data:'],
            objectSrc: ["'none'"],
            scriptSrc: ["'self'", (req, res) => `'nonce-${res.locals.cspNonce}'`],
            scriptSrcAttr: ["'none'"],
            styleSrc: ["'self'", "'unsafe-inline'"]
        }
    },
    crossOriginEmbedderPolicy: false
}));
app.use((req, res, next) => {
    req.requestId = randomUUID();
    res.setHeader('X-Request-ID', req.requestId);
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Pragma', 'no-cache');
    next();
});
app.use(express.json({
    limit: '8kb',
    strict: true,
    verify: (req, res, buffer) => {
        req.rawBody = Buffer.from(buffer);
    }
}));
app.use(rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 300,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (req, res) => {
        recordRateLimitAlert(
            'rate_limit',
            'Limite de requisições excedido; novas requisições foram temporariamente bloqueadas.',
            req
        );
        res.status(429).json({ error: 'Muitas requisições. Aguarde alguns minutos e tente novamente.' });
    }
}));
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 20,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (req, res) => {
        recordRateLimitAlert(
            'login_rate_limit',
            'Muitas tentativas de autenticação foram bloqueadas temporariamente.',
            req
        );
        res.status(429).json({ error: 'Muitas tentativas. Aguarde 15 minutos e tente novamente.' });
    }
});
const registrationLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    limit: 5,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    handler: (req, res) => {
        res.status(429).json({ error: 'Limite de cadastros excedido. Tente novamente mais tarde.' });
    }
});

function recordAudit(userId, action, req) {
    statements.insertAudit.run(userId || null, action, req.socket.remoteAddress || null);
}

function recordSecurityEvent(type, message, req) {
    const result = statements.insertSecurityEvent.run(type, message, req.socket.remoteAddress || null);
    const event = {
        id: Number(result.lastInsertRowid),
        event_type: type,
        message,
        created_at: new Date().toISOString()
    };
    for (const subscriber of securityEventSubscribers) subscriber(event);
}

function recordRateLimitAlert(type, message, req) {
    const ipAddress = req.socket.remoteAddress || 'unknown';
    const key = `${type}:${ipAddress}`;
    const now = Date.now();
    if (now - (rateLimitAlertTimes.get(key) || 0) < 15 * 60 * 1000) return;
    rateLimitAlertTimes.set(key, now);
    recordSecurityEvent(type, message, req);
}

const maintenanceTimer = setInterval(() => {
    const now = Date.now();
    statements.deleteExpiredSessions.run(now);

    for (const [key, attempt] of failedLogins) {
        if (now - attempt.startedAt >= 15 * 60 * 1000) failedLogins.delete(key);
    }
    for (const [key, timestamp] of deniedAccessAlerts) {
        if (now - timestamp >= 5 * 60 * 1000) deniedAccessAlerts.delete(key);
    }
    for (const [key, timestamp] of rateLimitAlertTimes) {
        if (now - timestamp >= 15 * 60 * 1000) rateLimitAlertTimes.delete(key);
    }
}, 5 * 60 * 1000);
maintenanceTimer.unref();

function sendLoginPage(req, res, next) {
    fs.readFile(loginPath, 'utf8', (error, html) => {
        if (error) return next(error);
        const nonce = res.locals.cspNonce;
        const page = html.replace(/<script(?=[\s>])/g, `<script nonce="${nonce}"`);
        res.type('html').send(page);
    });
}

function requestCookies(req) {
    const cookieHeader = req.headers.cookie || '';
    const cookies = new Map();

    for (const part of cookieHeader.split(';')) {
        const separator = part.indexOf('=');
        if (separator > 0) {
            cookies.set(part.slice(0, separator).trim(), part.slice(separator + 1).trim());
        }
    }

    return cookies;
}

function requireSameOrigin(req, res, next) {
    const origin = req.get('origin');
    if (origin !== expectedOrigin) {
        recordRateLimitAlert(
            'origin_rejected',
            'Uma alteração foi bloqueada porque a origem da requisição não corresponde ao site.',
            req
        );
        return res.status(403).json({ error: 'Origem da requisição não permitida.' });
    }

    if (!req.is('application/json')) {
        return res.status(415).json({ error: 'Envie a requisição como application/json.' });
    }

    return next();
}

function loadSession(req, res, next) {
    const token = requestCookies(req).get(sessionCookie);
    if (!token || !/^[A-Za-z0-9_-]{40,50}$/.test(token)) {
        req.user = null;
        return next();
    }

    const session = statements.findSession.get(hashToken(token));
    if (!session || session.is_active !== 1 || session.expires_at <= Date.now()) {
        statements.deleteSession.run(hashToken(token));
        req.user = null;
        return next();
    }

    req.user = {
        id: session.id,
        email: session.email,
        role: session.role
    };
    return next();
}

function requireAuthentication(req, res, next) {
    if (!req.user) {
        const key = req.socket.remoteAddress || 'unknown';
        const now = Date.now();
        const lastAlert = deniedAccessAlerts.get(key) || 0;
        if (now - lastAlert > 5 * 60 * 1000) {
            deniedAccessAlerts.set(key, now);
            recordSecurityEvent(
                'protected_page_blocked',
                'Acesso ao painel protegido sem uma sessão autenticada foi bloqueado.',
                req
            );
        }

        if (req.path.endsWith('.html')) return sendLoginPage(req, res, next);
        return res.status(401).json({ error: 'Autenticação necessária.' });
    }

    return next();
}

function requireAdmin(req, res, next) {
    if (req.user.role !== 'admin') {
        recordRateLimitAlert(
            'admin_access_denied',
            'Uma conta de cliente tentou acessar uma função exclusiva de administração.',
            req
        );
        return res.status(403).json({ error: 'Acesso restrito a administradores.' });
    }

    return next();
}

function usesSyncPayFor(req) {
    return syncPayEnabled && req.user && req.user.role === 'admin';
}

function requireSyncPayLive(req, res, next) {
    if (!syncPayEnabled) {
        return res.status(503).json({ error: 'A integração SyncPay não está ativada neste servidor.' });
    }
    if (!usesSyncPayFor(req)) {
        return res.status(403).json({ error: 'A integração SyncPay está restrita aos administradores.' });
    }
    return next();
}

function isValidSyncPayCustomer(document, phone) {
    return /^\d{11}$|^\d{14}$/.test(document) && /^\d{10,11}$/.test(phone);
}

async function addPixQrCode(charge) {
    if (!charge || typeof charge.pixCode !== 'string' || !charge.pixCode) return charge;
    return {
        ...charge,
        pixQrCodeDataUrl: await QRCode.toDataURL(charge.pixCode, {
            errorCorrectionLevel: 'M',
            margin: 1,
            width: 240
        })
    };
}

function normalizeProviderDate(value) {
    const timestamp = typeof value === 'string' ? Date.parse(value) : NaN;
    return Number.isFinite(timestamp) ? new Date(timestamp).toISOString() : null;
}

app.use(loadSession);

app.get('/healthz', (req, res) => {
    try {
        db.prepare('SELECT 1').get();
        return res.status(200).json({ status: 'ok' });
    } catch (error) {
        console.error(`[${req.requestId}] Health check failed:`, error);
        return res.status(503).json({ status: 'unavailable' });
    }
});

app.get('/assets/fussionpay-logo.png', (req, res, next) => {
    res.sendFile(logoPath, error => {
        if (error) next(error);
    });
});

app.get('/assets/fussionpay-shark.svg', (req, res, next) => {
    res.sendFile(sharkPath, error => {
        if (error) next(error);
    });
});

app.get('/', (req, res, next) => {
    if (req.user) return res.redirect('/fussionpay_painel.html');
    return sendLoginPage(req, res, next);
});

app.get('/login', (req, res, next) => {
    if (req.user) return res.redirect('/fussionpay_painel.html');
    return sendLoginPage(req, res, next);
});

app.get('/fussionpay_painel.html', requireAuthentication, (req, res, next) => {
    fs.readFile(panelPath, 'utf8', (error, html) => {
        if (error) return next(error);
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        const nonce = res.locals.cspNonce;
        res.send(html.replace(/<script(?=[\s>])/g, `<script nonce="${nonce}"`));
    });
});

app.get('/api/auth/me', requireAuthentication, (req, res) => {
    res.json({ user: req.user });
});

app.post('/api/auth/register', requireSameOrigin, registrationLimiter, async (req, res) => {
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = req.body.password;

    if (!isValidEmail(email) || typeof password !== 'string'
        || password.length < 12 || password.length > 128) {
        return res.status(400).json({
            error: 'Informe um e-mail válido e uma senha entre 12 e 128 caracteres.'
        });
    }

    const passwordHash = await hashPassword(password);
    const userId = randomUUID();

    try {
        statements.insertUser.run(userId, email, passwordHash, 'customer');
    } catch (error) {
        if (error.code === 'SQLITE_CONSTRAINT_UNIQUE'
            || error.message.includes('UNIQUE constraint failed: users.email')) {
            return res.status(409).json({ error: 'Não foi possível criar a conta com esses dados.' });
        }
        throw error;
    }

    const token = createSessionToken();
    const expiresAt = Date.now() + sessionDurationMs;
    statements.insertSession.run(hashToken(token), userId, expiresAt);
    recordAudit(userId, 'customer.registered', req);

    res.cookie(sessionCookie, token, {
        httpOnly: true,
        secure: isProduction,
        sameSite: 'strict',
        path: '/',
        maxAge: sessionDurationMs
    });
    return res.status(201).json({ user: { id: userId, email, role: 'customer' } });
});

app.post('/api/auth/login', requireSameOrigin, loginLimiter, async (req, res) => {
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = req.body.password;
    if (typeof password !== 'string' || password.length > 128 || email.length > 254) {
        return res.status(400).json({ error: 'E-mail ou senha inválidos.' });
    }

    const ipAddress = req.socket.remoteAddress || 'unknown';
    const key = `${ipAddress}:${hashToken(email).slice(0, 32)}`;
    const now = Date.now();
    const prior = failedLogins.get(key);
    const attempts = prior && now - prior.startedAt < 15 * 60 * 1000
        ? prior
        : { startedAt: now, count: 0, alerted: false };

    if (attempts.count >= 8) {
        return res.status(429).json({ error: 'Muitas tentativas. Aguarde 15 minutos antes de tentar novamente.' });
    }

    const user = isValidEmail(email) ? statements.findUserByEmail.get(email) : null;
    const passwordMatches = user
        ? await verifyPassword(password, user.password_hash)
        : await hashPassword('invalid-login-attempt');

    if (!user || user.is_active !== 1 || !passwordMatches) {
        attempts.count += 1;
        if (attempts.count >= 5 && !attempts.alerted) {
            attempts.alerted = true;
            recordSecurityEvent(
                'repeated_login_failure',
                'Foram detectadas várias tentativas de login sem sucesso para a mesma conta.',
                req
            );
        }
        failedLogins.set(key, attempts);
        return res.status(401).json({ error: 'E-mail ou senha inválidos.' });
    }

    failedLogins.delete(key);
    statements.deleteExpiredSessions.run(Date.now());
    const token = createSessionToken();
    const expiresAt = Date.now() + sessionDurationMs;
    statements.insertSession.run(hashToken(token), user.id, expiresAt);
    recordAudit(user.id, 'auth.login', req);

    res.cookie(sessionCookie, token, {
        httpOnly: true,
        secure: isProduction,
        sameSite: 'strict',
        path: '/',
        maxAge: sessionDurationMs
    });
    return res.json({
        user: { id: user.id, email: user.email, role: user.role }
    });
});

app.post('/api/auth/logout', requireSameOrigin, requireAuthentication, (req, res) => {
    const token = requestCookies(req).get(sessionCookie);
    if (token) statements.deleteSession.run(hashToken(token));
    recordAudit(req.user.id, 'auth.logout', req);
    res.clearCookie(sessionCookie, {
        httpOnly: true,
        secure: isProduction,
        sameSite: 'strict',
        path: '/'
    });
    return res.status(204).end();
});

app.get('/api/payments/config', requireAuthentication, (req, res) => {
    const mode = syncPayEnabled
        ? usesSyncPayFor(req) ? 'syncpay_live' : 'disabled'
        : paymentMode;
    return res.json({
        mode,
        livePayments: mode === 'syncpay_live',
        message: mode === 'disabled'
            ? syncPayEnabled
                ? 'A operação de pagamentos está disponível somente para a equipe autorizada.'
                : 'SyncPay ainda não está configurada neste servidor.'
            : null
    });
});

function sendSyncPayAdminError(req, res, error, action) {
    recordAudit(req.user.id, `${action}.failed`, req);
    if (!(error instanceof SyncPayApiError)) throw error;
    return res.status(error.statusCode === 429 ? 429 : 502).json({
        error: error.statusCode === 429
            ? 'A SyncPay limitou as solicitações. Aguarde antes de tentar novamente.'
            : 'Não foi possível concluir a operação com a SyncPay.'
    });
}

app.get(
    '/api/admin/syncpay/balance',
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        try {
            const result = await syncPayClient.getBalance();
            if (!result || typeof result.balance !== 'string'
                || !/^\d+(?:\.\d{1,2})?$/.test(result.balance)) {
                return res.status(502).json({ error: 'A SyncPay retornou um saldo inválido.' });
            }
            recordAudit(req.user.id, 'syncpay.balance.read', req);
            return res.json({ balance: result.balance });
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.balance');
        }
    }
);

app.get(
    '/api/admin/syncpay/profile',
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        try {
            const result = await syncPayClient.getProfile();
            const profile = result && result.data;
            if (!profile || typeof profile.client_id !== 'string'
                || typeof profile.status !== 'string') {
                return res.status(502).json({ error: 'A SyncPay retornou um perfil inválido.' });
            }
            recordAudit(req.user.id, 'syncpay.profile.read', req);
            return res.json({
                profile: {
                    clientId: profile.client_id,
                    name: typeof profile.name === 'string' ? profile.name : null,
                    email: typeof profile.email === 'string' ? profile.email : null,
                    status: profile.status
                }
            });
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.profile');
        }
    }
);

app.get(
    '/api/admin/syncpay/webhooks',
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
        const perPageText = req.query.per_page;
        const perPage = perPageText === undefined ? 15 : Number(perPageText);
        if (search.length > 100 || !Number.isInteger(perPage) || perPage < 1 || perPage > 100) {
            return res.status(400).json({ error: 'Filtros de webhooks inválidos.' });
        }

        try {
            const result = await syncPayClient.listWebhooks({ search, perPage });
            const data = result && Array.isArray(result.data) ? result.data : null;
            if (!data) return res.status(502).json({ error: 'A SyncPay retornou uma lista inválida.' });
            recordAudit(req.user.id, 'syncpay.webhooks.listed', req);
            return res.json({
                data: data.map(webhook => ({
                    id: webhook.id,
                    title: webhook.title,
                    url: webhook.url,
                    event: webhook.event,
                    trigger_all_products: webhook.trigger_all_products,
                    created_at: webhook.created_at
                })),
                meta: result.meta || null
            });
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.webhooks.list');
        }
    }
);

function buildSyncPayWebhookPayload(body, res) {
    const title = typeof body.title === 'string' ? body.title.trim() : '';
    if (!title || title.length > 120) {
        res.status(400).json({ error: 'Informe um título de webhook com até 120 caracteres.' });
        return null;
    }
    if (body.event !== 'transaction' || body.trigger_all_products !== true) {
        res.status(400).json({
            error: 'Use o evento transaction e trigger_all_products=true para o webhook FussionPay.'
        });
        return null;
    }
    return {
        title,
        url: `${expectedOrigin}/api/webhooks/syncpay`,
        event: 'transaction',
        trigger_all_products: true
    };
}

app.post(
    '/api/admin/syncpay/webhooks',
    requireSameOrigin,
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        const payload = buildSyncPayWebhookPayload(req.body, res);
        if (!payload) return;
        try {
            const result = await syncPayClient.createWebhook(payload);
            if (!result || typeof result.token !== 'string' || !result.token) {
                return res.status(502).json({
                    error: 'A SyncPay não retornou o token de webhook esperado; verifique o painel do provedor.'
                });
            }
            recordAudit(req.user.id, 'syncpay.webhooks.created', req);
            res.setHeader('Cache-Control', 'no-store');
            return res.status(201).json({ webhook: result });
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.webhooks.create');
        }
    }
);

app.put(
    '/api/admin/syncpay/webhooks/:id',
    requireSameOrigin,
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        const webhookId = Number(req.params.id);
        if (!Number.isSafeInteger(webhookId) || webhookId < 1) {
            return res.status(400).json({ error: 'Identificador de webhook inválido.' });
        }
        const payload = buildSyncPayWebhookPayload(req.body, res);
        if (!payload) return;
        try {
            const result = await syncPayClient.updateWebhook(webhookId, payload);
            recordAudit(req.user.id, 'syncpay.webhooks.updated', req);
            return res.json({ webhook: result });
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.webhooks.update');
        }
    }
);

app.delete(
    '/api/admin/syncpay/webhooks/:id',
    requireSameOrigin,
    requireAuthentication,
    requireAdmin,
    requireSyncPayLive,
    async (req, res) => {
        const webhookId = Number(req.params.id);
        if (!Number.isSafeInteger(webhookId) || webhookId < 1) {
            return res.status(400).json({ error: 'Identificador de webhook inválido.' });
        }
        try {
            const result = await syncPayClient.deleteWebhook(webhookId);
            recordAudit(req.user.id, 'syncpay.webhooks.deleted', req);
            return res.json(result);
        } catch (error) {
            return sendSyncPayAdminError(req, res, error, 'syncpay.webhooks.delete');
        }
    }
);

app.get('/api/customers', requireAuthentication, (req, res) => {
    return res.json({ customers: statements.listCustomersByOwner.all(req.user.id) });
});

app.post('/api/customers', requireSameOrigin, requireAuthentication, (req, res) => {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    if (name.length < 1 || name.length > 160 || !isValidEmail(email)) {
        return res.status(400).json({ error: 'Informe um nome e um e-mail válidos.' });
    }

    const customerId = randomUUID();
    try {
        statements.insertCustomer.run(customerId, req.user.id, name, email);
    } catch (error) {
        if (error.code === 'SQLITE_CONSTRAINT_UNIQUE'
            || error.message.includes('UNIQUE constraint failed: customers.owner_user_id, customers.email')) {
            return res.status(409).json({ error: 'Já existe um cliente com esse e-mail.' });
        }
        throw error;
    }

    recordAudit(req.user.id, 'customer.created', req);
    return res.status(201).json({
        customer: statements.findCustomerByOwnerEmail.get(req.user.id, email)
    });
});

function listCharges(req, res) {
    if (usesSyncPayFor(req)) {
        return res.json({
            mode: 'syncpay_live',
            charges: statements.listSyncPayChargesByOwner.all(req.user.id)
        });
    }
    if (paymentMode === 'sandbox') {
        return res.json({
            mode: 'sandbox',
            charges: statements.listSandboxChargesByOwner.all(req.user.id)
        });
    }
    return res.json({ mode: 'disabled', charges: [] });
}
app.get('/api/charges', requireAuthentication, listCharges);
app.get('/api/payments', requireAuthentication, listCharges);

function getChargeStatus(req, res) {
    if (!usesSyncPayFor(req)) {
        return res.status(403).json({ error: 'O acompanhamento SyncPay está indisponível.' });
    }
    const charge = statements.findSyncPayChargeStatusByIdAndOwner.get(req.user.id, req.params.id);
    if (!charge) return res.status(404).json({ error: 'Cobrança não encontrada.' });
    return res.json({
        charge,
        statusChecksRemaining: Math.max(0, 5 - charge.statusQueryCount)
    });
}
app.get('/api/charges/:id/status', requireAuthentication, getChargeStatus);
app.get('/api/payments/:id/status', requireAuthentication, getChargeStatus);

async function getCharge(req, res) {
    if (usesSyncPayFor(req)) {
        const charge = statements.findSyncPayChargeByIdAndOwner.get(req.user.id, req.params.id);
        if (!charge) return res.status(404).json({ error: 'Cobrança não encontrada.' });
        return res.json({
            charge: await addPixQrCode(charge),
            mode: 'syncpay_live',
            sandbox: false
        });
    }

    if (paymentMode !== 'sandbox') {
        return res.status(404).json({ error: 'Cobrança não encontrada.' });
    }
    const charge = statements.findSandboxChargeByIdAndOwner.get(req.user.id, req.params.id);
    if (!charge) return res.status(404).json({ error: 'Cobrança não encontrada.' });
    return res.json({ charge, sandbox: true, paymentCreated: false });
}
app.get('/api/charges/:id', requireAuthentication, getCharge);
app.get('/api/payments/:id', requireAuthentication, getCharge);

async function refreshSyncPayStatus(req, res) {
    if (!usesSyncPayFor(req)) {
        return res.status(403).json({
            error: 'A consulta SyncPay está disponível somente para a equipe autorizada.'
        });
    }

    const current = statements.findSyncPayChargeStatusByIdAndOwner.get(req.user.id, req.params.id);
    if (!current) return res.status(404).json({ error: 'Cobrança não encontrada.' });
    if (!current.providerIdentifier) {
        return res.status(409).json({ error: 'A cobrança ainda não possui identificador SyncPay consultável.' });
    }

    if (!['pending', 'refunding'].includes(current.status)) {
        const charge = statements.findSyncPayChargeByIdAndOwner.get(req.user.id, current.id);
        return res.json({
            charge: await addPixQrCode(charge),
            statusChecksRemaining: Math.max(0, 5 - current.statusQueryCount)
        });
    }

    const reservation = statements.reserveSyncPayStatusQuery.run(current.id, req.user.id);
    if (Number(reservation.changes) !== 1) {
        return res.status(429).json({
            error: 'O limite oficial de cinco consultas por transação foi atingido.',
            statusChecksRemaining: 0
        });
    }

    let providerTransaction;
    try {
        providerTransaction = await syncPayClient.getTransaction(current.providerIdentifier);
    } catch (error) {
        recordAudit(req.user.id, 'charge.syncpay.status_query_failed', req);
        return res.status(error instanceof SyncPayApiError && error.statusCode === 429 ? 429 : 502)
            .json({
                error: error instanceof SyncPayApiError && error.statusCode === 429
                    ? 'A SyncPay limitou as consultas. Aguarde antes de tentar novamente.'
                    : 'Não foi possível consultar o status na SyncPay.',
                statusChecksRemaining: Math.max(0, 4 - current.statusQueryCount)
            });
    }

    const providerAmountCents = Math.round(providerTransaction.amount * 100);
    if (providerAmountCents !== current.amountCents) {
        recordAudit(req.user.id, 'charge.syncpay.status_amount_mismatch', req);
        return res.status(502).json({
            error: 'O valor consultado na SyncPay não corresponde à cobrança registrada.',
            statusChecksRemaining: Math.max(0, 4 - current.statusQueryCount)
        });
    }

    const statusUpdatedAt = normalizeProviderDate(providerTransaction.updatedAt)
        || new Date().toISOString();
    const paidAt = normalizeProviderDate(providerTransaction.paidAt)
        || (providerTransaction.status === 'completed' ? statusUpdatedAt : null);
    statements.updateSyncPayChargeStatus.run(
        providerTransaction.status,
        statusUpdatedAt,
        providerTransaction.status,
        paidAt,
        providerTransaction.referenceId,
        statusUpdatedAt
    );
    recordAudit(req.user.id, 'charge.syncpay.status_refreshed', req);

    const charge = statements.findSyncPayChargeByIdAndOwner.get(req.user.id, current.id);
    return res.json({
        charge: await addPixQrCode(charge),
        statusChecksRemaining: Math.max(0, 4 - current.statusQueryCount)
    });
}
app.post('/api/charges/:id/refresh', requireSameOrigin, requireAuthentication, refreshSyncPayStatus);
app.post('/api/payments/:id/refresh', requireSameOrigin, requireAuthentication, refreshSyncPayStatus);

async function createCharge(req, res) {
    const amountCents = req.body.amountCents;
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const paymentMethod = req.body.paymentMethod;
    const description = typeof req.body.description === 'string' ? req.body.description.trim() : '';

    if (!Number.isSafeInteger(amountCents) || amountCents < 1 || amountCents > 1_000_000_000) {
        return res.status(400).json({ error: 'Informe um valor válido em centavos.' });
    }
    if (name.length < 1 || name.length > 160 || !isValidEmail(email)) {
        return res.status(400).json({ error: 'Informe um nome e um e-mail válidos para o cliente.' });
    }
    if (!['pix', 'boleto'].includes(paymentMethod)) {
        return res.status(400).json({ error: 'Método de pagamento indisponível.' });
    }
    if (description.length > 200) {
        return res.status(400).json({ error: 'A descrição deve ter no máximo 200 caracteres.' });
    }

    if (syncPayEnabled && !usesSyncPayFor(req)) {
        return res.status(403).json({
            error: 'A criação de PIX real está restrita à equipe autorizada da FussionPay.'
        });
    }
    if (!syncPayEnabled && paymentMode !== 'sandbox') {
        return res.status(503).json({
            error: 'Pagamentos estão indisponíveis. Configure a integração SyncPay no servidor.'
        });
    }

    if (usesSyncPayFor(req)) {
        const document = typeof req.body.document === 'string'
            ? req.body.document.replace(/\D/g, '')
            : '';
        const phone = typeof req.body.phone === 'string'
            ? req.body.phone.replace(/\D/g, '')
            : '';
        const idempotencyKey = req.get('idempotency-key') || '';

        if (paymentMethod !== 'pix') {
            return res.status(400).json({ error: 'A integração SyncPay habilitada aceita somente PIX.' });
        }
        if (!isValidSyncPayCustomer(document, phone)) {
            return res.status(400).json({
                error: 'Informe CPF/CNPJ e telefone válidos para criar o PIX.'
            });
        }
        if (req.body.liveConsent !== true) {
            return res.status(400).json({
                error: 'Confirme que esta operação cria um PIX real e autorize o envio dos dados à SyncPay.'
            });
        }
        if (!/^[A-Za-z0-9._:-]{8,128}$/.test(idempotencyKey)) {
            return res.status(400).json({ error: 'Chave de idempotência inválida.' });
        }

        const existing = statements.findSyncPayChargeByIdempotencyKeyAndOwner.get(
            req.user.id,
            idempotencyKey
        );
        if (existing) {
            const sameRequest = existing.amountCents === amountCents
                && existing.description === description
                && existing.customerName === name
                && existing.customerEmail === email;
            if (!sameRequest) {
                return res.status(409).json({
                    error: 'Esta chave já foi usada com outros dados. Não crie outra cobrança até verificar a anterior.'
                });
            }

            const charge = statements.findSyncPayChargeByIdAndOwner.get(req.user.id, existing.id);
            if (['pending', 'completed', 'refunding', 'refunded', 'chargeback', 'med'].includes(existing.status)) {
                return res.status(200).json({
                    charge: await addPixQrCode(charge),
                    mode: 'syncpay_live',
                    paymentRequestCreated: true,
                    message: 'Cobrança SyncPay já registrada para esta solicitação.'
                });
            }
            if (existing.status === 'failed' || existing.status === 'refused'
                || existing.status === 'three_ds_failed') {
                return res.status(409).json({
                    error: 'A solicitação anterior falhou. Gere uma nova tentativa somente após conferir o painel SyncPay.',
                    retryWithNewKey: true
                });
            }
            return res.status(409).json({
                error: 'O resultado da solicitação anterior ainda é incerto. Confira a conta SyncPay antes de tentar novamente.'
            });
        }

        const candidateCustomerId = randomUUID();
        const customerResult = statements.insertCustomerIfMissing.run(
            candidateCustomerId,
            req.user.id,
            name,
            email
        );
        const customer = statements.findCustomerByOwnerEmail.get(req.user.id, email);
        if (Number(customerResult.changes) > 0) recordAudit(req.user.id, 'customer.created', req);

        const chargeId = randomUUID();
        statements.insertSyncPayCharge.run(
            chargeId,
            req.user.id,
            customer.id,
            amountCents,
            description,
            idempotencyKey
        );

        let providerResult;
        try {
            providerResult = await syncPayClient.createCashIn(buildCashInPayload({
                amountCents,
                description,
                name,
                document,
                email,
                phone
            }));
        } catch (error) {
            const uncertain = error instanceof SyncPayApiError && error.uncertain;
            statements.setSyncPayChargeFailure.run(
                uncertain ? 'creation_unknown' : 'failed',
                chargeId
            );
            recordAudit(
                req.user.id,
                uncertain ? 'charge.syncpay.creation_unknown' : 'charge.syncpay.creation_failed',
                req
            );
            if (uncertain) {
                return res.status(503).json({
                    error: 'Não foi possível confirmar o resultado na SyncPay. Confira a conta antes de criar outra cobrança.',
                    charge: statements.findSyncPayChargeByIdAndOwner.get(req.user.id, chargeId)
                });
            }

            return res.status(502).json({
                error: error instanceof SyncPayApiError && error.statusCode === 422
                    ? 'A SyncPay rejeitou os dados da cobrança.'
                    : 'Não foi possível criar a cobrança na SyncPay.',
                retryWithNewKey: true
            });
        }

        statements.setSyncPayChargeProviderResult.run(
            providerResult.identifier,
            providerResult.pixCode,
            chargeId
        );
        for (const event of statements.listSyncPayWebhookEventsByIdentifier.all(providerResult.identifier)) {
            statements.updateSyncPayChargeStatus.run(
                event.status,
                event.occurredAt,
                event.status,
                event.status === 'completed' ? event.occurredAt : null,
                providerResult.identifier,
                event.occurredAt
            );
        }
        recordAudit(req.user.id, 'charge.created.syncpay', req);
        return res.status(201).json({
            charge: await addPixQrCode(
                statements.findSyncPayChargeByIdAndOwner.get(req.user.id, chargeId)
            ),
            mode: 'syncpay_live',
            paymentRequestCreated: true,
            message: 'PIX criado na SyncPay. O pagamento ainda está pendente.'
        });
    }

    const candidateCustomerId = randomUUID();
    const customerResult = statements.insertCustomerIfMissing.run(
        candidateCustomerId,
        req.user.id,
        name,
        email
    );
    const customer = statements.findCustomerByOwnerEmail.get(req.user.id, email);
    if (Number(customerResult.changes) > 0) recordAudit(req.user.id, 'customer.created', req);

    const chargeId = randomUUID();
    statements.insertSandboxCharge.run(
        chargeId,
        req.user.id,
        customer.id,
        amountCents,
        paymentMethod,
        description
    );
    recordAudit(req.user.id, 'charge.created.sandbox', req);

    const charge = statements.findSandboxChargeByIdAndOwner.get(req.user.id, chargeId);
    return res.status(201).json({
        charge,
        sandbox: true,
        paymentCreated: false,
        message: 'Cobrança registrada no sandbox; nenhum pagamento real foi criado.'
    });
}
app.post('/api/charges', requireSameOrigin, requireAuthentication, createCharge);
app.post('/api/payments', requireSameOrigin, requireAuthentication, createCharge);

app.post('/api/webhooks/syncpay', (req, res) => {
    if (!syncPayEnabled) return res.status(404).json({ error: 'Webhook não habilitado.' });

    if (!verifySyncPaySignature(
        req.rawBody,
        req.get('x-syncpay-signature'),
        process.env.SYNCPAY_WEBHOOK_SECRET
    )) {
        recordRateLimitAlert(
            'syncpay_webhook_signature_rejected',
            'Um webhook SyncPay foi rejeitado por assinatura inválida ou expirada.',
            req
        );
        return res.status(401).json({ error: 'Assinatura do webhook inválida.' });
    }

    const eventName = req.get('x-syncpay-event');
    const event = req.body;
    const transaction = event && event.transaction;
    const occurredAtMs = Date.parse(event && event.occurred_at);
    const status = transaction && normalizeSyncPayStatus(transaction.status);
    if (!['transaction.created', 'transaction.updated'].includes(eventName)
        || event.event !== eventName
        || typeof event.event_id !== 'string'
        || event.event_id.length < 1
        || event.event_id.length > 128
        || !transaction
        || typeof transaction.reference_id !== 'string'
        || transaction.reference_id.length > 128
        || !status
        || !Number.isFinite(occurredAtMs)) {
        return res.status(400).json({ error: 'Evento SyncPay inválido.' });
    }

    const occurredAt = new Date(occurredAtMs).toISOString();
    const inserted = statements.insertSyncPayWebhookEvent.run(
        event.event_id,
        transaction.reference_id,
        status,
        occurredAt
    );
    if (Number(inserted.changes) === 0) {
        return res.status(200).json({ received: true, duplicate: true });
    }

    const paidAt = normalizeProviderDate(transaction.paid_at)
        || (status === 'completed' ? occurredAt : null);
    statements.updateSyncPayChargeStatus.run(
        status,
        occurredAt,
        status,
        paidAt,
        transaction.reference_id,
        occurredAt
    );
    return res.status(200).json({ received: true });
});

app.get('/api/security/alerts/stream', requireAuthentication, requireAdmin, (req, res) => {
    res.status(200);
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    res.write('retry: 5000\nevent: ready\ndata: {}\n\n');

    const subscriber = event => {
        res.write(`event: security-alert\ndata: ${JSON.stringify(event)}\n\n`);
    };
    securityEventSubscribers.add(subscriber);
    securityEventResponses.add(res);
    const heartbeat = setInterval(() => res.write(': keep-alive\n\n'), 20000);

    req.on('close', () => {
        clearInterval(heartbeat);
        securityEventSubscribers.delete(subscriber);
        securityEventResponses.delete(res);
    });
});

app.get('/api/security/alerts', requireAuthentication, requireAdmin, (req, res) => {
    res.json({ alerts: statements.listSecurityEvents.all() });
});

app.get('/api/admin/audit-logs', requireAuthentication, requireAdmin, (req, res) => {
    res.json({ logs: statements.listAuditLogs.all() });
});

app.post('/api/security/alerts/:id/acknowledge', requireSameOrigin, requireAuthentication, requireAdmin, (req, res) => {
    const alertId = Number(req.params.id);
    if (!Number.isSafeInteger(alertId) || alertId < 1) {
        return res.status(400).json({ error: 'Identificador de alerta inválido.' });
    }

    statements.acknowledgeSecurityEvent.run(alertId);
    recordAudit(req.user.id, 'security.alert.acknowledged', req);
    return res.status(204).end();
});

app.use((req, res) => {
    res.status(404).json({ error: 'Recurso não encontrado.' });
});

app.use((error, req, res, next) => {
    console.error(`[${req.requestId}]`, error);
    if (res.headersSent) return next(error);

    if (error instanceof SyntaxError && error.status === 400 && 'body' in error) {
        return res.status(400).json({ error: 'JSON inválido.' });
    }

    try {
        recordSecurityEvent(
            'application_error',
            'O servidor encontrou um erro interno ao processar uma requisição.',
            req
        );
    } catch (alertError) {
        console.error(`[${req.requestId}] Não foi possível persistir o alerta de erro:`, alertError);
    }

    return res.status(500).json({
        error: 'Erro interno. Se o problema persistir, informe o suporte.',
        requestId: req.requestId
    });
});

const server = app.listen(port, host, () => {
    console.log(`FussionPay disponível em ${expectedOrigin}`);
    console.log('Banco local SQLite inicializado. Administradores são criados pelo comando npm run admin:create.');
});

function closeServer() {
    clearInterval(maintenanceTimer);
    for (const response of securityEventResponses) response.end();
    server.close(() => {
        db.close();
        process.exit(0);
    });
}

process.on('SIGINT', closeServer);
process.on('SIGTERM', closeServer);
