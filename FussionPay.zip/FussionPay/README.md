# FussionPay

O login usa um servidor e banco SQLite local. Por padrão, os pagamentos estão desativados; cobranças PIX SyncPay reais só podem ser habilitadas com configuração segura de produção.

## Executar localmente

Use Node.js 22.13 ou superior. No terminal PowerShell do VS Code, dentro da pasta do projeto:

```powershell
npm.cmd install
npm.cmd run admin:create -- admin@seu-dominio.com
npm.cmd start
```

O comando de administrador solicita a senha sem exibi-la e não cria uma conta padrão. Clientes podem criar suas próprias contas na tela de login. Abra **http://127.0.0.1:5501/**; use esse endereço em vez do servidor Live Server do VS Code.

Para redefinir a senha de uma conta de administrador existente, execute:

```powershell
npm.cmd run admin:reset
```

Informe o e-mail do administrador e digite a nova senha duas vezes. A senha não aparece no terminal; as sessões anteriores são revogadas. Esse procedimento é local e não substitui a recuperação de conta para usuários em produção.

O banco local é criado fora da pasta do projeto, em `%LOCALAPPDATA%\FussionPay\fussionpay.sqlite` no Windows (ou na pasta de dados do usuário em outros sistemas). Isso impede que um servidor estático do projeto o publique. Faça cópias de segurança em local protegido.

## Pagamentos

O padrão é **pagamentos desativados**. O sandbox só fica acessível quando `PAYMENT_MODE=sandbox` é definido
explicitamente em ambiente de desenvolvimento/teste; ele é bloqueado em produção. O Cash-In PIX da SyncPay só é
habilitado com `PAYMENT_MODE=syncpay_live`, `NODE_ENV=production` e as variáveis abaixo configuradas no ambiente
privado do servidor (ou em um arquivo `.env` local, ignorado pelo Git):

- `SYNCPAY_CLIENT_ID`
- `SYNCPAY_CLIENT_SECRET`
- `SYNCPAY_WEBHOOK_SECRET` — segredo exibido uma única vez ao cadastrar o webhook SyncPay.

Copie `.env.example` para `.env` para desenvolvimento local; ele mantém pagamentos desativados. **Não troque
essas opções locais para produção.** No serviço de hospedagem, configure os segredos no painel de variáveis
protegidas do provedor de deploy (sem enviar pelo chat, navegador ou repositório):

```text
NODE_ENV=production
APP_ORIGIN=https://fussionpay.com.br
PAYMENT_MODE=syncpay_live
SYNCPAY_CLIENT_ID=(credencial SyncPay)
SYNCPAY_CLIENT_SECRET=(segredo SyncPay)
SYNCPAY_WEBHOOK_SECRET=(segredo do webhook SyncPay)
```

O host usa `PORT` fornecida pela plataforma ou `5501`; em produção o processo escuta em `0.0.0.0` se `HOST`
não estiver definido. A aplicação encerra a inicialização se produção não usar `APP_ORIGIN` HTTPS ou se faltar
qualquer segredo obrigatório. Inicie/reinicie o serviço com `npm start`; use `/healthz` como health check.

**A API pública consultada não documenta um sandbox separado.** `syncpay_live` pode criar PIX reais. Por
segurança, a criação está restrita ao administrador da FussionPay; clientes comuns não recebem cobranças de
demonstração nem acesso à conta SyncPay. Isso ainda não é um gateway multi-lojista: onboarding/KYC de lojistas,
split/repasse, precificação e conciliação ainda precisam ser implementados e aprovados antes de operar para
terceiros. A tela exige CPF/CNPJ, telefone e confirmação antes de enviar os dados do pagador à SyncPay; esses dois
campos não são persistidos pelo FussionPay.

Configure na SyncPay um webhook HTTPS público para o evento `transaction`, apontando para
`https://fussionpay.com.br/api/webhooks/syncpay`. O servidor verifica `X-SyncPay-Signature` com o corpo bruto e uma
janela de cinco minutos, e deduplica pelo `event_id`. Não use o callback legado `cashin.*` nesta rota: ele não usa
HMAC. O webhook deve ser a fonte principal do status; a API SyncPay limita consultas de status a cinco por
transação.

O código de referência `syncpayments-node-sqlite.zip` foi analisado e integrado seletivamente ao servidor existente:
saldo, dados básicos do perfil e gerenciamento de webhooks usam o adaptador central SyncPay e exigem sessão de
administrador. As rotas são `GET /api/admin/syncpay/balance`, `GET /api/admin/syncpay/profile` e
`GET|POST|PUT|DELETE /api/admin/syncpay/webhooks`. A criação é limitada ao evento `transaction` e ao callback
FussionPay. O token retornado na criação aparece uma única vez na resposta protegida; configure-o como
`SYNCPAY_WEBHOOK_SECRET` no ambiente privado e não o registre ou compartilhe. A lista de webhooks não retorna tokens.
Não copiamos o servidor Express/SQLite independente do ZIP: a aplicação já tem autenticação, schema e proteção de
webhook próprios.

O painel recebe o QR Code localmente a partir do `pix_code` e acompanha o status salvo no servidor a cada 15
segundos; esse acompanhamento não consulta a SyncPay. Se necessário, **Atualizar status pela SyncPay** usa
`GET /api/partner/v2/transactions/{reference_id}`. O FussionPay limita suas consultas manuais a cinco por cobrança,
persiste `paid_at` quando o status confiável é `completed` e não usa o navegador para confirmar pagamento.
`GET /api/charges/:id/status` (também disponível em `/api/payments/:id/status`) apenas lê o estado atualizado pelo
webhook. `POST /api/charges/:id/refresh` (ou `/api/payments/:id/refresh`) faz a consulta de contingência.

Se uma chamada de criação tiver resultado de rede incerto, o sistema não a repete automaticamente. Confira o
painel SyncPay antes de criar outra cobrança. Use somente chaves rotacionadas; nunca salve credenciais em HTML,
JavaScript do navegador, repositório ou conversa.

A comissão adicional da FussionPay ainda não está configurada: o `split` da SyncPay direciona uma porcentagem
para outra conta e não calcula automaticamente uma taxa adicional. Saques/Cash-Out ainda não foram conectados:
o ZIP de referência também deixa a criação do CashOut explicitamente como HTTP 501 porque não contém o contrato
oficial da requisição. Os eventos de webhook de CashOut não são suficientes para criar uma solicitação de saque;
não invente endpoint nem payload.

Antes de habilitar a operação: confirme com a SyncPay que sua conta aprovada está autorizada para o modelo de
negócio e volume pretendidos, obtenha os termos/tarifas e cadastre o webhook. Configure o DNS de
`fussionpay.com.br` para a hospedagem e ative HTTPS antes de definir `APP_ORIGIN` como
`https://fussionpay.com.br`. Hospede o servidor com banco persistente, backups e monitoramento. O endereço local
`127.0.0.1:5501` continua sendo apenas para desenvolvimento e não é acessível pela SyncPay para webhooks.

## Sandbox de desenvolvimento

O sandbox é somente local/desenvolvimento e requer `PAYMENT_MODE=sandbox` explícito. Para cobrança local nenhuma
requisição é enviada à SyncPay; produção recusa esse modo.

Depois de entrar no painel, clientes e cobranças de demonstração são salvos no banco local e separados por conta:

- `GET /api/customers` e `POST /api/customers` (`name`, `email`).
- `GET /api/charges`, `GET /api/charges/:id` e `POST /api/charges`.
- Os caminhos `/api/payments` e `/api/payments/:id` são aliases autenticados das rotas de cobrança. Eles usam
  sessão do painel, não API Keys de lojistas; em produção, criação e consulta SyncPay permanecem restritas ao
  administrador da FussionPay.
- A criação de cobrança recebe `amountCents` como inteiro, `paymentMethod` (`pix` ou `boleto`), `name`, `email` e `description` opcional.

Essas cobranças ficam com o status `sandbox_created`. Nenhum PIX, boleto, pagamento ou movimentação financeira é gerado; o endpoint informa `paymentCreated: false`. Cartões não são aceitos. As rotas exigem sessão autenticada, e operações de escrita exigem origem e JSON válidos.

## Proteções implementadas

- Senhas salvas como hashes scrypt com salt; nenhuma senha em texto puro é persistida.
- Sessões aleatórias armazenadas no banco somente como hashes e enviadas em cookies HttpOnly e SameSite.
- Expiração de sessão, invalidação no logout, limitação de tentativas de login e rate limiting de requisições.
- Verificação de origem, limite no tamanho do JSON e consultas SQL preparadas.
- Cadastro público só cria contas de cliente; administradores são criados pelo terminal.
- A página do painel e APIs administrativas exigem sessão de servidor e, nas APIs administrativas, papel de administrador.
- Alertas de acessos bloqueados, tentativas repetidas de login e erros internos são persistidos e enviados em tempo real aos administradores conectados.
- Ações de autenticação e revisão de alertas são registradas em auditoria; cabeçalhos HTTP de segurança estão ativos.
- Scripts autorizados por nonce CSP por resposta; handlers de eventos inline foram removidos do painel.
- Cookies são marcados como Secure quando `NODE_ENV=production`.
- Clientes e cobranças de sandbox são consultados por conta autenticada; valores são armazenados em centavos e consultas usam parâmetros preparados.

## Antes de qualquer publicação

Este início **não está pronto para operação financeira de produção**. O adaptador SyncPay não foi testado contra uma conta do provedor nem substitui revisão comercial, jurídica, de segurança e compliance. Ainda faltam PostgreSQL/Supabase gerenciado, HTTPS e configuração de proxy, autenticação multifator, recuperação de conta, rate limiting distribuído, backups gerenciados, monitoramento operacional e revisão de segurança/compliance.

Não exponha o servidor de desenvolvimento diretamente à internet. Antes da produção financeira, migre para
PostgreSQL gerenciado, publique atrás de HTTPS, configure `NODE_ENV=production` e o `APP_ORIGIN` público exato,
implemente MFA e recuperação de conta, configure backups e entrega externa de alertas e realize uma revisão de
segurança e compliance. Não armazene dados de cartão. O `index.html` redireciona agora para a origem relativa,
e `/healthz` verifica se o processo consegue consultar o banco local.
