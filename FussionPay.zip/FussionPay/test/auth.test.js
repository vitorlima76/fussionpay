const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { once } = require('node:events');
const { after, before, test } = require('node:test');
const { randomBytes, randomUUID } = require('node:crypto');
const { hashPassword } = require('../src/security');

const root = path.join(__dirname, '..');
const adminEmail = 'admin@example.test';
const adminPassword = randomBytes(32).toString('base64url') + 'A1!';
const customerPassword = randomBytes(32).toString('base64url') + 'B2!';
let baseUrl;
let databasePath;
let temporaryDirectory;
let database;
let serverProcess;
let serverError = '';
let adminCookie;
let customerCookie;

async function findAvailablePort() {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1');
    await once(listener, 'listening');
    const { port } = listener.address();
    await new Promise((resolve, reject) => listener.close(error => error ? reject(error) : resolve()));
    return port;
}

async function waitForServer() {
    for (let attempt = 0; attempt < 100; attempt += 1) {
        if (serverProcess.exitCode !== null) {
            throw new Error(`Test server exited during startup: ${serverError}`);
        }
        try {
            const response = await fetch(baseUrl);
            if (response.ok) return;
        } catch {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    }

    throw new Error(`Test server did not start: ${serverError}`);
}

function cookieFrom(response) {
    const cookie = response.headers.getSetCookie()
        .find(value => value.startsWith('fussionpay_session='));
    assert.ok(cookie, 'authentication response should set a session cookie');
    assert.match(cookie, /HttpOnly/i);
    assert.match(cookie, /SameSite=Strict/i);
    return cookie.split(';', 1)[0];
}

async function postJson(route, body, options = {}) {
    return fetch(baseUrl + route, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Origin: options.origin || baseUrl,
            ...(options.cookie ? { Cookie: options.cookie } : {})
        },
        body: JSON.stringify(body)
    });
}

before(async () => {
    temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'fussionpay-auth-'));
    databasePath = path.join(temporaryDirectory, 'test.sqlite');
    process.env.DATABASE_PATH = databasePath;
    const databaseModule = require('../src/db');
    database = databaseModule.db;

    databaseModule.statements.insertUser.run(
        randomUUID(),
        adminEmail,
        await hashPassword(adminPassword),
        'admin'
    );

    const port = await findAvailablePort();
    baseUrl = `http://127.0.0.1:${port}`;
    serverProcess = spawn(process.execPath, ['server.js'], {
        cwd: root,
        env: {
            ...process.env,
            HOST: '127.0.0.1',
            PORT: String(port),
            APP_ORIGIN: baseUrl,
            DATABASE_PATH: databasePath,
            PAYMENT_MODE: 'sandbox',
            NODE_ENV: 'test'
        },
        stdio: ['ignore', 'ignore', 'pipe']
    });
    serverProcess.stderr.on('data', chunk => {
        serverError += chunk.toString();
    });

    await waitForServer();
});

after(async () => {
    if (serverProcess && serverProcess.exitCode === null) {
        serverProcess.kill();
        await Promise.race([
            once(serverProcess, 'exit'),
            new Promise(resolve => setTimeout(resolve, 5000))
        ]);
    }
    if (database) database.close();
    if (temporaryDirectory) {
        for (const suffix of ['', '-shm', '-wal']) {
            const filePath = databasePath + suffix;
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
        fs.rmdirSync(temporaryDirectory);
    }
    delete process.env.DATABASE_PATH;
});

test('unauthenticated requests receive no dashboard HTML', async () => {
    const response = await fetch(baseUrl + '/fussionpay_painel.html');
    const html = await response.text();

    assert.equal(response.status, 200);
    assert.match(html, /Bem-vindo de volta/);
    assert.match(response.headers.get('content-security-policy'), /script-src-attr 'none'/);
    assert.doesNotMatch(response.headers.get('content-security-policy'), /script-src[^;]*'unsafe-inline'/);
    assert.match(html, /<script nonce="[A-Za-z0-9+/=]+">/);
    assert.doesNotMatch(html, /id="appLayout"/);
    assert.doesNotMatch(html, /R\$ 0,00/);
});

test('health check reports database availability without authentication', async () => {
    const response = await fetch(baseUrl + '/healthz');
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { status: 'ok' });
});

test('cross-origin account creation is rejected', async () => {
    const response = await postJson('/api/auth/register', {
        email: 'blocked@example.test',
        password: 'CustomerSecurePass123!'
    }, { origin: 'https://attacker.invalid' });

    assert.equal(response.status, 403);
});

test('customer password is hashed and admin screens are not authorized', async () => {
    const registration = await postJson('/api/auth/register', {
        email: 'customer@example.test',
        password: customerPassword,
        role: 'admin'
    });
    assert.equal(registration.status, 201);
    assert.equal((await registration.json()).user.role, 'customer');
    customerCookie = cookieFrom(registration);

    const customer = database.prepare(
        'SELECT password_hash, role FROM users WHERE email = ?'
    ).get('customer@example.test');
    assert.equal(customer.role, 'customer');
    assert.match(customer.password_hash, /^scrypt\$/);
    assert.notEqual(customer.password_hash, customerPassword);

    const panel = await fetch(baseUrl + '/fussionpay_painel.html', {
        headers: { Cookie: customerCookie }
    });
    const panelHtml = await panel.text();
    assert.equal(panel.status, 200);
    assert.match(panelHtml, /id="appLayout"/);
    assert.match(panelHtml, /<script nonce="[A-Za-z0-9+/=]+">/);
    assert.doesNotMatch(panelHtml, /\bonclick\s*=/i);
    assert.doesNotMatch(panelHtml, /\boninput\s*=/i);
    assert.match(panelHtml, /data-admin-only hidden/);

    const forbidden = await fetch(baseUrl + '/api/security/alerts', {
        headers: { Cookie: customerCookie }
    });
    assert.equal(forbidden.status, 403);

    const auditForbidden = await fetch(baseUrl + '/api/admin/audit-logs', {
        headers: { Cookie: customerCookie }
    });
    assert.equal(auditForbidden.status, 403);
    const syncPayAdminForbidden = await fetch(baseUrl + '/api/admin/syncpay/balance', {
        headers: { Cookie: customerCookie }
    });
    assert.equal(syncPayAdminForbidden.status, 403);
});

test('sandbox customers and charges persist without processing payments', async () => {
    const paymentConfig = await fetch(baseUrl + '/api/payments/config', {
        headers: { Cookie: customerCookie }
    });
    assert.deepEqual(await paymentConfig.json(), {
        mode: 'sandbox',
        livePayments: false,
        message: null
    });

    const customerResponse = await postJson('/api/customers', {
        name: 'Cliente Sandbox',
        email: 'buyer@example.test'
    }, { cookie: customerCookie });
    assert.equal(customerResponse.status, 201);
    const { customer } = await customerResponse.json();
    assert.equal(customer.email, 'buyer@example.test');

    const duplicateCustomer = await postJson('/api/customers', {
        name: 'Cliente duplicado',
        email: 'BUYER@example.test'
    }, { cookie: customerCookie });
    assert.equal(duplicateCustomer.status, 409);

    const createdCharge = await postJson('/api/charges', {
        amountCents: 1599,
        name: customer.name,
        email: customer.email,
        paymentMethod: 'pix',
        description: 'Pedido de teste'
    }, { cookie: customerCookie });
    assert.equal(createdCharge.status, 201);
    const result = await createdCharge.json();
    assert.equal(result.charge.amountCents, 1599);
    assert.equal(result.charge.status, 'sandbox_created');
    assert.equal(result.sandbox, true);
    assert.equal(result.paymentCreated, false);

    const listResponse = await fetch(baseUrl + '/api/charges', {
        headers: { Cookie: customerCookie }
    });
    assert.equal(listResponse.status, 200);
    assert.equal((await listResponse.json()).charges.length, 1);
    const detailResponse = await fetch(baseUrl + '/api/charges/' + result.charge.id, {
        headers: { Cookie: customerCookie }
    });
    assert.equal(detailResponse.status, 200);
    assert.equal((await detailResponse.json()).charge.id, result.charge.id);
    const paymentAlias = await fetch(baseUrl + '/api/payments', {
        headers: { Cookie: customerCookie }
    });
    assert.equal((await paymentAlias.json()).charges.length, 1);
    const paymentDetailAlias = await fetch(baseUrl + '/api/payments/' + result.charge.id, {
        headers: { Cookie: customerCookie }
    });
    assert.equal((await paymentDetailAlias.json()).charge.id, result.charge.id);
    const disabledProviderStatus = await fetch(
        baseUrl + '/api/payments/' + result.charge.id + '/status',
        { headers: { Cookie: customerCookie } }
    );
    assert.equal(disabledProviderStatus.status, 403);

    const invalidAmount = await postJson('/api/charges', {
        amountCents: 0,
        name: customer.name,
        email: customer.email,
        paymentMethod: 'pix'
    }, { cookie: customerCookie });
    assert.equal(invalidAmount.status, 400);

    const cardCharge = await postJson('/api/charges', {
        amountCents: 1599,
        name: customer.name,
        email: customer.email,
        paymentMethod: 'card'
    }, { cookie: customerCookie });
    assert.equal(cardCharge.status, 400);

    const otherRegistration = await postJson('/api/auth/register', {
        email: `other-${randomUUID()}@example.test`,
        password: 'AnotherSecurePass123!'
    });
    assert.equal(otherRegistration.status, 201);
    const otherCookie = cookieFrom(otherRegistration);
    const otherCharges = await fetch(baseUrl + '/api/charges', {
        headers: { Cookie: otherCookie }
    });
    assert.deepEqual((await otherCharges.json()).charges, []);
    const otherCustomers = await fetch(baseUrl + '/api/customers', {
        headers: { Cookie: otherCookie }
    });
    assert.deepEqual((await otherCustomers.json()).customers, []);
    const hiddenCharge = await fetch(baseUrl + '/api/charges/' + result.charge.id, {
        headers: { Cookie: otherCookie }
    });
    assert.equal(hiddenCharge.status, 404);
});

test('SyncPay webhook remains unavailable while payment mode is sandbox', async () => {
    const response = await fetch(baseUrl + '/api/webhooks/syncpay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    assert.equal(response.status, 404);
});

test('repeated invalid passwords are throttled without revealing the account', async () => {
    let response;
    for (let attempt = 0; attempt < 8; attempt += 1) {
        response = await postJson('/api/auth/login', {
            email: 'unknown@example.test',
            password: 'DefinitelyWrongPassword!'
        });
        assert.equal(response.status, 401);
        assert.deepEqual(await response.json(), { error: 'E-mail ou senha inválidos.' });
    }

    response = await postJson('/api/auth/login', {
        email: 'unknown@example.test',
        password: 'DefinitelyWrongPassword!'
    });
    assert.equal(response.status, 429);
});

test('admin can review alerts and logout invalidates its session', async () => {
    const login = await postJson('/api/auth/login', {
        email: adminEmail,
        password: adminPassword
    });
    assert.equal(login.status, 200);
    adminCookie = cookieFrom(login);

    const alertsResponse = await fetch(baseUrl + '/api/security/alerts', {
        headers: { Cookie: adminCookie }
    });
    assert.equal(alertsResponse.status, 200);
    const { alerts } = await alertsResponse.json();
    assert.ok(alerts.some(alert => alert.event_type === 'origin_rejected'));
    assert.ok(alerts.some(alert => alert.event_type === 'admin_access_denied'));
    assert.ok(alerts.some(alert => alert.event_type === 'repeated_login_failure'));

    const auditResponse = await fetch(baseUrl + '/api/admin/audit-logs', {
        headers: { Cookie: adminCookie }
    });
    assert.equal(auditResponse.status, 200);
    const { logs } = await auditResponse.json();
    assert.ok(logs.some(log => log.action === 'customer.registered'));

    const logout = await postJson('/api/auth/logout', {}, { cookie: adminCookie });
    assert.equal(logout.status, 204);

    const afterLogout = await fetch(baseUrl + '/fussionpay_painel.html', {
        headers: { Cookie: adminCookie }
    });
    assert.doesNotMatch(await afterLogout.text(), /id="appLayout"/);
});

test('resetting an admin password revokes sessions and accepts the new password', async () => {
    const login = await postJson('/api/auth/login', {
        email: adminEmail,
        password: adminPassword
    });
    assert.equal(login.status, 200);
    const oldCookie = cookieFrom(login);
    const newPassword = randomBytes(32).toString('base64url') + 'C3!';
    const newPasswordHash = await hashPassword(newPassword);
    const { resetAdminPassword } = require('../src/admin');
    assert.throws(
        () => resetAdminPassword('customer@example.test', 'not-a-password-hash'),
        /Administrador ativo não encontrado/
    );
    const reset = resetAdminPassword(adminEmail, newPasswordHash);
    assert.equal(reset.revokedSessions, 1);

    const oldSession = await fetch(baseUrl + '/api/auth/me', {
        headers: { Cookie: oldCookie }
    });
    assert.equal(oldSession.status, 401);

    const newLogin = await postJson('/api/auth/login', {
        email: adminEmail,
        password: newPassword
    });
    assert.equal(newLogin.status, 200);
    assert.match(database.prepare('SELECT password_hash FROM users WHERE email = ?')
        .get(adminEmail).password_hash, /^scrypt\$/);
});
