const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { test } = require('node:test');

const root = path.join(__dirname, '..');

test('SyncPay charge migration preserves existing records and adds status fields', () => {
    const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'fussionpay-migration-'));
    const databasePath = path.join(temporaryDirectory, 'legacy.sqlite');
    const legacyDatabase = new DatabaseSync(databasePath);
    legacyDatabase.exec(`
        CREATE TABLE syncpay_charges (
            id TEXT PRIMARY KEY,
            owner_user_id TEXT NOT NULL,
            customer_id TEXT NOT NULL,
            amount_cents INTEGER NOT NULL,
            currency TEXT NOT NULL DEFAULT 'BRL',
            payment_method TEXT NOT NULL DEFAULT 'pix',
            status TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            idempotency_key TEXT NOT NULL,
            provider_identifier TEXT UNIQUE,
            pix_code TEXT,
            status_updated_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        INSERT INTO syncpay_charges (
            id, owner_user_id, customer_id, amount_cents, status, idempotency_key,
            provider_identifier, pix_code, created_at, updated_at
        ) VALUES (
            'charge-1', 'user-1', 'customer-1', 1467, 'pending', 'key-1',
            'provider-1', 'pix-code', '2025-01-01T00:00:00.000Z', '2025-01-01T00:00:00.000Z'
        );
    `);
    legacyDatabase.close();

    try {
        const inspection = spawnSync(process.execPath, ['-e', `
            const { db } = require('./src/db');
            const columns = db.prepare('PRAGMA table_info(syncpay_charges)').all().map(column => column.name);
            const charge = db.prepare('SELECT id, amount_cents, status, status_query_count, paid_at, expires_at FROM syncpay_charges WHERE id = ?').get('charge-1');
            console.log(JSON.stringify({ columns, charge }));
            db.close();
        `], {
            cwd: root,
            encoding: 'utf8',
            env: { ...process.env, DATABASE_PATH: databasePath }
        });
        assert.equal(inspection.status, 0, inspection.stderr);
        const { columns, charge } = JSON.parse(inspection.stdout.trim());
        assert.ok(columns.includes('status_query_count'));
        assert.ok(columns.includes('paid_at'));
        assert.ok(columns.includes('expires_at'));
        assert.deepEqual(charge, {
            id: 'charge-1',
            amount_cents: 1467,
            status: 'pending',
            status_query_count: 0,
            paid_at: null,
            expires_at: null
        });
    } finally {
        for (const name of ['legacy.sqlite', 'legacy.sqlite-shm', 'legacy.sqlite-wal']) {
            const filePath = path.join(temporaryDirectory, name);
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
        fs.rmdirSync(temporaryDirectory);
    }
});
