const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { createHmac, randomBytes, randomUUID } = require('node:crypto');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { once } = require('node:events');
const { after, before, test } = require('node:test');
const { hashPassword } = require('../src/security');

const root = path.join(__dirname, '..');
const webhookSecret = 'syncpay-webhook-secret-for-tests';
const appOrigin = 'https://payments.example.test';
let baseUrl;
let databasePath;
let temporaryDirectory;
let database;
let serverProcess;
let serverError = '';
let adminCookie;
let otherAdminCookie;

async function findAvailablePort() {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1');
    await once(listener, 'listening');
    const { port } = listener.address();
    await new Promise((resolve, reject) => {
        listener.close(error => error ? reject(error) : resolve());
    });
    return port;
}

async function waitForServer() {
    for (let attempt = 0; attempt < 100; attempt += 1) {
        if (serverProcess.exitCode !== null) {
            throw new Error(`Test server exited during startup: ${serverError}`);
        }
        try {
            const response = await fetch(baseUrl + '/healthz');
            if (response.ok) return;
        } catch {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    }
    throw new Error(`Test server did not start: ${serverError}`);
}

async function login(email, password) {
    const response = await fetch(baseUrl + '/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Origin: appOrigin
        },
        body: JSON.stringify({ email, password })
    });
    assert.equal(response.status, 200);
    return response.headers.getSetCookie()
        .find(value => value.startsWith('fussionpay_session='))
        .split(';', 1)[0];
}

async function postJson(route, body, cookie, additionalHeaders = {}) {
    return fetch(baseUrl + route, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Origin: appOrigin,
            Cookie: cookie,
            ...additionalHeaders
        },
        body: JSON.stringify(body)
    });
}

async function createCharge(cookie, idempotencyKey) {
    return postJson('/api/payments', {
        amountCents: 1467,
        name: 'Cliente de teste',
        email: 'buyer@example.test',
        paymentMethod: 'pix',
        description: 'Pedido de teste',
        document: '12345678901',
        phone: '11999998888',
        liveConsent: true
    }, cookie, { 'Idempotency-Key': idempotencyKey });
}

async function sendWebhook(cookie, providerIdentifier, eventId, status) {
    const timestamp = Math.floor(Date.now() / 1000);
    const body = JSON.stringify({
        event: 'transaction.updated',
        event_id: eventId,
        occurred_at: new Date().toISOString(),
        transaction: {
            reference_id: providerIdentifier,
            status,
            paid_at: status === 'completed' ? new Date().toISOString() : null
        }
    });
    const signature = createHmac('sha256', webhookSecret)
        .update(`${timestamp}.`)
        .update(body)
        .digest('hex');
    return fetch(baseUrl + '/api/webhooks/syncpay', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-syncpay-signature': `t=${timestamp},v1=${signature}`,
            'x-syncpay-event': 'transaction.updated'
        },
        body
    });
}

before(async () => {
    temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'fussionpay-syncpay-live-'));
    databasePath = path.join(temporaryDirectory, 'test.sqlite');
    process.env.DATABASE_PATH = databasePath;
    const databaseModule = require('../src/db');
    database = databaseModule.db;

    const firstPassword = randomBytes(32).toString('base64url') + 'A1!';
    const secondPassword = randomBytes(32).toString('base64url') + 'B2!';
    databaseModule.statements.insertUser.run(
        randomUUID(),
        'admin@example.test',
        await hashPassword(firstPassword),
        'admin'
    );
    databaseModule.statements.insertUser.run(
        randomUUID(),
        'other-admin@example.test',
        await hashPassword(secondPassword),
        'admin'
    );

    const preloadPath = path.join(temporaryDirectory, 'mock-syncpay.js');
    fs.writeFileSync(preloadPath, `
        let chargeNumber = 0;
        globalThis.fetch = async (input, options = {}) => {
            const url = String(input);
            if (url.endsWith('/auth-token')) {
                return new Response(JSON.stringify({ access_token: 'test-token', expires_in: 3600 }), { status: 200 });
            }
            if (url.endsWith('/cash-in')) {
                chargeNumber += 1;
                return new Response(JSON.stringify({
                    identifier: 'provider-' + chargeNumber,
                    pix_code: '000201pix-code-for-tests'
                }), { status: 200 });
            }
            if (url.endsWith('/balance')) {
                return new Response(JSON.stringify({ balance: '90.00' }), { status: 200 });
            }
            if (url.endsWith('/profile')) {
                return new Response(JSON.stringify({
                    data: {
                        client_id: 'syncpay-profile-id',
                        name: 'FussionPay Account',
                        email: 'account@example.test',
                        status: 'approved',
                        document: 'private-document',
                        phone: 'private-phone'
                    }
                }), { status: 200 });
            }
            if (url.includes('/webhooks?')) {
                return new Response(JSON.stringify({
                    data: [{
                        id: 7,
                        title: 'Existing webhook',
                        url: 'https://payments.example.test/api/webhooks/syncpay',
                        event: 'transaction',
                        trigger_all_products: true,
                        created_at: '2026-01-01 00:00:00',
                        token: 'must-not-be-listed'
                    }],
                    meta: { current_page: 1, per_page: 15, has_more_pages: false }
                }), { status: 200 });
            }
            if (url.endsWith('/webhooks') && options.method === 'POST') {
                return new Response(JSON.stringify({
                    id: 8,
                    title: 'FussionPay transactions',
                    url: 'https://payments.example.test/api/webhooks/syncpay',
                    event: 'transaction',
                    trigger_all_products: true,
                    token: 'one-time-webhook-secret'
                }), { status: 201 });
            }
            if (url.endsWith('/webhooks/8') && options.method === 'PUT') {
                return new Response(JSON.stringify({ id: 8, title: 'Updated FussionPay webhook' }), {
                    status: 200
                });
            }
            if (url.endsWith('/webhooks/8') && options.method === 'DELETE') {
                return new Response(JSON.stringify({ message: 'Webhook deleted' }), { status: 200 });
            }
            if (url.includes('/api/partner/v2/transactions/')) {
                const reference = decodeURIComponent(url.slice(url.lastIndexOf('/') + 1));
                const status = reference === 'provider-1' ? 'completed' : 'pending';
                const updatedAt = new Date().toISOString();
                return new Response(JSON.stringify({
                    data: {
                        transaction: {
                            reference_id: reference,
                            status,
                            amount: 14.67,
                            paid_at: status === 'completed' ? updatedAt : null,
                            updated_at: updatedAt
                        }
                    }
                }), { status: 200 });
            }
            return new Response(JSON.stringify({ message: 'Unexpected test request' }), { status: 500 });
        };
    `);

    const port = await findAvailablePort();
    baseUrl = `http://127.0.0.1:${port}`;
    serverProcess = spawn(process.execPath, ['--require', preloadPath, 'server.js'], {
        cwd: root,
        env: {
            ...process.env,
            HOST: '127.0.0.1',
            PORT: String(port),
            APP_ORIGIN: appOrigin,
            DATABASE_PATH: databasePath,
            NODE_ENV: 'production',
            PAYMENT_MODE: 'syncpay_live',
            SYNCPAY_CLIENT_ID: 'test-client-id',
            SYNCPAY_CLIENT_SECRET: 'test-client-secret',
            SYNCPAY_WEBHOOK_SECRET: webhookSecret
        },
        stdio: ['ignore', 'ignore', 'pipe']
    });
    serverProcess.stderr.on('data', chunk => {
        serverError += chunk.toString();
    });
    await waitForServer();
    adminCookie = await login('admin@example.test', firstPassword);
    otherAdminCookie = await login('other-admin@example.test', secondPassword);
});

after(async () => {
    if (serverProcess && serverProcess.exitCode === null) {
        serverProcess.kill();
        await Promise.race([
            once(serverProcess, 'exit'),
            new Promise(resolve => setTimeout(resolve, 5000))
        ]);
    }
    if (database) database.close();
    if (temporaryDirectory) {
        for (const name of ['test.sqlite', 'test.sqlite-shm', 'test.sqlite-wal', 'mock-syncpay.js']) {
            const filePath = path.join(temporaryDirectory, name);
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
        fs.rmdirSync(temporaryDirectory);
    }
    delete process.env.DATABASE_PATH;
});

test('live PIX creation returns the real provider code, a QR image, and honors idempotency and ownership', async () => {
    const response = await createCharge(adminCookie, 'create-charge-key-0001');
    assert.equal(response.status, 201);
    const result = await response.json();
    assert.equal(result.charge.providerIdentifier, 'provider-1');
    assert.equal(result.charge.pixCode, '000201pix-code-for-tests');
    assert.match(result.charge.pixQrCodeDataUrl, /^data:image\/png;base64,/);

    const retry = await createCharge(adminCookie, 'create-charge-key-0001');
    assert.equal(retry.status, 200);
    assert.equal((await retry.json()).charge.id, result.charge.id);

    const hidden = await fetch(baseUrl + '/api/payments/' + result.charge.id, {
        headers: { Cookie: otherAdminCookie }
    });
    assert.equal(hidden.status, 404);
});

test('SyncPay account and webhook administration is authenticated and keeps secrets out of list responses', async () => {
    const balance = await fetch(baseUrl + '/api/admin/syncpay/balance', {
        headers: { Cookie: adminCookie }
    });
    assert.deepEqual(await balance.json(), { balance: '90.00' });

    const profile = await fetch(baseUrl + '/api/admin/syncpay/profile', {
        headers: { Cookie: adminCookie }
    });
    assert.deepEqual(await profile.json(), {
        profile: {
            clientId: 'syncpay-profile-id',
            name: 'FussionPay Account',
            email: 'account@example.test',
            status: 'approved'
        }
    });

    const webhookList = await fetch(baseUrl + '/api/admin/syncpay/webhooks?per_page=15', {
        headers: { Cookie: adminCookie }
    });
    const webhookListBody = await webhookList.json();
    assert.equal(webhookListBody.data[0].id, 7);
    assert.equal('token' in webhookListBody.data[0], false);

    const webhookCreate = await postJson('/api/admin/syncpay/webhooks', {
        title: 'FussionPay transactions',
        event: 'transaction',
        trigger_all_products: true
    }, adminCookie);
    const webhookCreateBody = await webhookCreate.text();
    assert.equal(webhookCreate.status, 201, webhookCreateBody);
    assert.equal(webhookCreate.headers.get('cache-control'), 'no-store');
    const createdWebhook = JSON.parse(webhookCreateBody);
    assert.equal(createdWebhook.webhook.token, 'one-time-webhook-secret');
    assert.equal(
        createdWebhook.webhook.url,
        'https://payments.example.test/api/webhooks/syncpay'
    );

    const invalidWebhook = await postJson('/api/admin/syncpay/webhooks', {
        title: 'Legacy callback',
        event: 'cashin',
        trigger_all_products: true
    }, adminCookie);
    assert.equal(invalidWebhook.status, 400);

    const update = await fetch(baseUrl + '/api/admin/syncpay/webhooks/8', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            Origin: appOrigin,
            Cookie: adminCookie
        },
        body: JSON.stringify({
            title: 'Updated FussionPay webhook',
            event: 'transaction',
            trigger_all_products: true
        })
    });
    assert.equal(update.status, 200);

    const remove = await fetch(baseUrl + '/api/admin/syncpay/webhooks/8', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            Origin: appOrigin,
            Cookie: adminCookie
        },
        body: '{}'
    });
    assert.equal(remove.status, 200);

    const otherAdmin = await fetch(baseUrl + '/api/admin/syncpay/balance', {
        headers: { Cookie: otherAdminCookie }
    });
    assert.equal(otherAdmin.status, 200);

    const unauthenticated = await fetch(baseUrl + '/api/admin/syncpay/balance');
    assert.equal(unauthenticated.status, 401);
});

test('manual status lookup persists paid_at and stops querying terminal transactions', async () => {
    const charges = await fetch(baseUrl + '/api/payments', {
        headers: { Cookie: adminCookie }
    });
    const charge = (await charges.json()).charges[0];
    const response = await postJson(
        `/api/payments/${charge.id}/refresh`,
        {},
        adminCookie
    );
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.charge.status, 'completed');
    assert.ok(Number.isFinite(Date.parse(result.charge.paidAt)));
    assert.equal(result.statusChecksRemaining, 4);

    const terminalRetry = await postJson(`/api/payments/${charge.id}/refresh`, {}, adminCookie);
    assert.equal((await terminalRetry.json()).charge.statusQueryCount, 1);
});

test('manual status queries stop at five while signed webhooks update and deduplicate events', async () => {
    const creation = await createCharge(adminCookie, 'create-charge-key-0002');
    const charge = (await creation.json()).charge;
    assert.equal(charge.providerIdentifier, 'provider-2');

    for (let query = 0; query < 5; query += 1) {
        const response = await postJson(`/api/payments/${charge.id}/refresh`, {}, adminCookie);
        assert.equal(response.status, 200);
    }
    const exceeded = await postJson(`/api/payments/${charge.id}/refresh`, {}, adminCookie);
    assert.equal(exceeded.status, 429);

    const invalidWebhook = await fetch(baseUrl + '/api/webhooks/syncpay', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-syncpay-event': 'transaction.updated',
            'x-syncpay-signature': 't=1,v1=invalid'
        },
        body: '{}'
    });
    assert.equal(invalidWebhook.status, 401);

    const webhook = await sendWebhook(adminCookie, 'provider-2', 'event-provider-2', 'completed');
    assert.equal(webhook.status, 200);
    const duplicate = await sendWebhook(adminCookie, 'provider-2', 'event-provider-2', 'completed');
    assert.deepEqual(await duplicate.json(), { received: true, duplicate: true });

    const status = await fetch(baseUrl + `/api/payments/${charge.id}/status`, {
        headers: { Cookie: adminCookie }
    });
    const updated = await status.json();
    assert.equal(updated.charge.status, 'completed');
    assert.ok(updated.charge.paidAt);
    assert.equal(updated.charge.statusQueryCount, 5);
});
