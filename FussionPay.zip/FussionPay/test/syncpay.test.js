const assert = require('node:assert/strict');
const { createHmac } = require('node:crypto');
const { test } = require('node:test');
const {
    SyncPayClient,
    buildCashInPayload,
    normalizeSyncPayStatus,
    verifySyncPaySignature
} = require('../src/syncpay');

test('Cash-In payload converts cents to reais and uses SyncPay field names', () => {
    assert.deepEqual(buildCashInPayload({
        amountCents: 1467,
        description: 'Pedido 123',
        name: 'Cliente',
        document: '12345678901',
        email: 'cliente@example.test',
        phone: '11999998888'
    }), {
        amount: 14.67,
        description: 'Pedido 123',
        client: {
            name: 'Cliente',
            document: '12345678901',
            email: 'cliente@example.test',
            phone: '11999998888'
        }
    });
});

test('SyncPay webhook signature checks raw bytes and rejects stale or altered deliveries', () => {
    const secret = 'webhook-secret-for-tests';
    const timestamp = Math.floor(Date.now() / 1000);
    const rawBody = Buffer.from('{"event":"transaction.updated"}');
    const digest = createHmac('sha256', secret)
        .update(`${timestamp}.`)
        .update(rawBody)
        .digest('hex');
    const signature = `t=${timestamp},v1=${digest}`;

    assert.equal(verifySyncPaySignature(rawBody, signature, secret), true);
    assert.equal(verifySyncPaySignature(Buffer.from('{}'), signature, secret), false);
    assert.equal(verifySyncPaySignature(
        rawBody,
        signature,
        secret,
        (timestamp - 301) * 1000
    ), false);
});

test('SyncPay client reuses its access token and validates Cash-In response', async () => {
    const requests = [];
    const client = new SyncPayClient({
        clientId: 'client-id',
        clientSecret: 'client-secret',
        fetchImpl: async (url, options) => {
            requests.push({ url, options });
            if (url.endsWith('/auth-token')) {
                return new Response(JSON.stringify({
                    access_token: 'access-token',
                    expires_in: 3600
                }), { status: 200 });
            }
            return new Response(JSON.stringify({
                identifier: 'provider-uuid',
                pix_code: '000201pix'
            }), { status: 200 });
        }
    });

    const first = await client.createCashIn({ amount: 14.67 });
    const second = await client.createCashIn({ amount: 15.01 });

    assert.deepEqual(first, { identifier: 'provider-uuid', pixCode: '000201pix' });
    assert.deepEqual(second, first);
    assert.equal(requests.filter(request => request.url.endsWith('/auth-token')).length, 1);
    assert.equal(requests.filter(request => request.url.endsWith('/cash-in')).length, 2);
    assert.equal(requests[1].options.headers.Authorization, 'Bearer access-token');
});

test('SyncPay status lookup uses the documented V2 route and validates the transaction identity', async () => {
    const requests = [];
    const client = new SyncPayClient({
        clientId: 'client-id',
        clientSecret: 'client-secret',
        fetchImpl: async (url, options) => {
            requests.push({ url, options });
            if (url.endsWith('/auth-token')) {
                return new Response(JSON.stringify({
                    access_token: 'access-token',
                    expires_in: 3600
                }), { status: 200 });
            }
            return new Response(JSON.stringify({
                data: {
                    transaction: {
                        reference_id: 'provider-uuid',
                        status: 'completed',
                        amount: 14.67,
                        paid_at: '2026-08-16T14:32:10Z',
                        updated_at: '2026-08-16T14:32:10Z'
                    }
                }
            }), { status: 200 });
        }
    });

    const transaction = await client.getTransaction('provider-uuid');

    assert.deepEqual(transaction, {
        referenceId: 'provider-uuid',
        status: 'completed',
        amount: 14.67,
        paidAt: '2026-08-16T14:32:10Z',
        updatedAt: '2026-08-16T14:32:10Z'
    });
    assert.equal(
        requests[1].url,
        'https://api.syncpayments.com.br/api/partner/v2/transactions/provider-uuid'
    );
    assert.equal(requests[1].options.headers.Authorization, 'Bearer access-token');

    const invalidClient = new SyncPayClient({
        clientId: 'client-id',
        clientSecret: 'client-secret',
        fetchImpl: async url => new Response(JSON.stringify(url.endsWith('/auth-token')
            ? { access_token: 'access-token', expires_in: 3600 }
            : { data: { transaction: { reference_id: 'other-uuid', status: 'completed', amount: 14.67 } } }),
        { status: 200 })
    });
    await assert.rejects(invalidClient.getTransaction('provider-uuid'), /dados esperados/);
});

test('SyncPay status lookup reports transport failures without exposing credentials', async () => {
    const client = new SyncPayClient({
        clientId: 'private-client-id',
        clientSecret: 'private-client-secret',
        fetchImpl: async url => {
            if (url.endsWith('/auth-token')) {
                return new Response(JSON.stringify({
                    access_token: 'access-token',
                    expires_in: 3600
                }), { status: 200 });
            }
            throw new Error('simulated timeout');
        }
    });

    await assert.rejects(client.getTransaction('provider-uuid'), error => {
        assert.equal(error.phase, 'transaction');
        assert.match(error.message, /Não foi possível consultar a transação/);
        assert.doesNotMatch(error.message, /private-client-id|private-client-secret/);
        return true;
    });
});

test('SyncPay account and webhook methods use documented partner v1 routes', async () => {
    const requests = [];
    const client = new SyncPayClient({
        clientId: 'client-id',
        clientSecret: 'client-secret',
        fetchImpl: async (url, options) => {
            requests.push({ url, options });
            if (url.endsWith('/auth-token')) {
                return new Response(JSON.stringify({
                    access_token: 'access-token',
                    expires_in: 3600
                }), { status: 200 });
            }
            if (url.endsWith('/balance')) return new Response('{"balance":"90.00"}');
            if (url.endsWith('/profile')) return new Response('{"data":{"status":"approved"}}');
            if (url.includes('/webhooks?')) return new Response('{"data":[],"meta":{"current_page":1}}');
            if (url.endsWith('/webhooks')) {
                return new Response('{"id":7,"token":"one-time-secret"}', { status: 201 });
            }
            if (url.endsWith('/webhooks/7') && options.method === 'PUT') {
                return new Response('{"id":7,"title":"Updated"}');
            }
            if (url.endsWith('/webhooks/7') && options.method === 'DELETE') {
                return new Response('{"message":"Webhook deleted"}');
            }
            return new Response('{}', { status: 404 });
        }
    });

    assert.deepEqual(await client.getBalance(), { balance: '90.00' });
    assert.deepEqual(await client.getProfile(), { data: { status: 'approved' } });
    assert.deepEqual(await client.listWebhooks({ search: 'Pix & checkout', perPage: 25 }), {
        data: [],
        meta: { current_page: 1 }
    });
    assert.deepEqual(await client.createWebhook({ title: 'FussionPay' }), {
        id: 7,
        token: 'one-time-secret'
    });
    assert.deepEqual(await client.updateWebhook(7, { title: 'Updated' }), {
        id: 7,
        title: 'Updated'
    });
    assert.deepEqual(await client.deleteWebhook(7), { message: 'Webhook deleted' });

    assert.ok(requests.some(request => request.url.endsWith('/api/partner/v1/balance')));
    assert.ok(requests.some(request => request.url.endsWith('/api/partner/v1/profile')));
    const listRequest = requests.find(request => request.url.includes('/api/partner/v1/webhooks?'));
    assert.ok(listRequest.url.includes('search=Pix+%26+checkout'));
    assert.ok(listRequest.url.includes('per_page=25'));
    const createRequest = requests.find(request => request.url.endsWith('/api/partner/v1/webhooks'));
    assert.equal(createRequest.options.method, 'POST');
    assert.deepEqual(JSON.parse(createRequest.options.body), { title: 'FussionPay' });
    assert.ok(requests.some(request => request.url.endsWith('/webhooks/7')
        && request.options.method === 'PUT'));
    assert.ok(requests.some(request => request.url.endsWith('/webhooks/7')
        && request.options.method === 'DELETE'));
});

test('SyncPay transaction statuses are allow-listed before updating local charges', () => {
    assert.equal(normalizeSyncPayStatus('completed'), 'completed');
    assert.equal(normalizeSyncPayStatus('med'), 'med');
    assert.equal(normalizeSyncPayStatus('unknown'), null);
});
