const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { once } = require('node:events');
const { after, before, test } = require('node:test');

const root = path.join(__dirname, '..');
let baseUrl;
let databasePath;
let temporaryDirectory;
let serverProcess;
let serverError = '';
let sessionCookie;

async function findAvailablePort() {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1');
    await once(listener, 'listening');
    const { port } = listener.address();
    await new Promise((resolve, reject) => listener.close(error => error ? reject(error) : resolve()));
    return port;
}

async function postJson(route, body, cookie) {
    return fetch(baseUrl + route, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Origin: baseUrl,
            ...(cookie ? { Cookie: cookie } : {})
        },
        body: JSON.stringify(body)
    });
}

before(async () => {
    temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'fussionpay-payments-'));
    databasePath = path.join(temporaryDirectory, 'test.sqlite');
    process.env.DATABASE_PATH = databasePath;
    require('../src/db');

    const port = await findAvailablePort();
    baseUrl = `http://127.0.0.1:${port}`;
    const env = {
        ...process.env,
        HOST: '127.0.0.1',
        PORT: String(port),
        APP_ORIGIN: baseUrl,
        DATABASE_PATH: databasePath,
        NODE_ENV: 'test'
    };
    delete env.PAYMENT_MODE;
    delete env.SYNCPAY_CLIENT_ID;
    delete env.SYNCPAY_CLIENT_SECRET;
    delete env.SYNCPAY_WEBHOOK_SECRET;

    serverProcess = spawn(process.execPath, ['server.js'], {
        cwd: root,
        env,
        stdio: ['ignore', 'ignore', 'pipe']
    });
    serverProcess.stderr.on('data', chunk => {
        serverError += chunk.toString();
    });

    for (let attempt = 0; attempt < 100; attempt += 1) {
        if (serverProcess.exitCode !== null) {
            throw new Error(`Test server exited during startup: ${serverError}`);
        }
        try {
            const response = await fetch(baseUrl);
            if (response.ok) return;
        } catch {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
    }

    throw new Error(`Test server did not start: ${serverError}`);
});

after(async () => {
    if (serverProcess && serverProcess.exitCode === null) {
        serverProcess.kill();
        await Promise.race([
            once(serverProcess, 'exit'),
            new Promise(resolve => setTimeout(resolve, 5000))
        ]);
    }
    const database = require('../src/db').db;
    database.close();
    if (temporaryDirectory) {
        for (const suffix of ['', '-shm', '-wal']) {
            const filePath = databasePath + suffix;
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
        fs.rmdirSync(temporaryDirectory);
    }
    delete process.env.DATABASE_PATH;
});

test('payments are disabled by default instead of silently falling back to sandbox', async () => {
    const registration = await postJson('/api/auth/register', {
        email: 'merchant@example.test',
        password: 'SecurePasswordForTest123!'
    });
    assert.equal(registration.status, 201);
    sessionCookie = registration.headers.getSetCookie()
        .find(value => value.startsWith('fussionpay_session='))
        .split(';', 1)[0];

    const configResponse = await fetch(baseUrl + '/api/payments/config', {
        headers: { Cookie: sessionCookie }
    });
    assert.deepEqual(await configResponse.json(), {
        mode: 'disabled',
        livePayments: false,
        message: 'SyncPay ainda não está configurada neste servidor.'
    });

    const chargesResponse = await fetch(baseUrl + '/api/charges', {
        headers: { Cookie: sessionCookie }
    });
    assert.deepEqual(await chargesResponse.json(), { mode: 'disabled', charges: [] });

    const panelResponse = await fetch(baseUrl + '/fussionpay_painel.html', {
        headers: { Cookie: sessionCookie }
    });
    const panel = await panelResponse.text();
    assert.match(panel, /Pagamentos indisponíveis/);
    assert.doesNotMatch(panel, /Ambiente de demonstração/);
    assert.doesNotMatch(panel, /MODO SANDBOX/);
    assert.doesNotMatch(panel, /pk_demo_|sk_demo_/);
    const rootRedirect = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
    assert.match(rootRedirect, /window\.location\.hostname\}:5501\//);
    assert.match(rootRedirect, /window\.location\.port !== '5501'/);
    assert.doesNotMatch(rootRedirect, /http-equiv="refresh"|location\.replace\('\/'\)/);
    assert.match(rootRedirect, /Inicie a aplicação com/);

    const chargeResponse = await postJson('/api/charges', {
        amountCents: 500,
        name: 'Cliente',
        email: 'buyer@example.test',
        paymentMethod: 'pix'
    }, sessionCookie);
    assert.equal(chargeResponse.status, 503);
});

test('a regular account cannot fall back to sandbox when SyncPay is configured live', async () => {
    const liveDatabasePath = path.join(temporaryDirectory, 'live.sqlite');
    const port = await findAvailablePort();
    const localUrl = `http://127.0.0.1:${port}`;
    const expectedOrigin = 'https://payments.example.test';
    const env = {
        ...process.env,
        HOST: '127.0.0.1',
        PORT: String(port),
        APP_ORIGIN: expectedOrigin,
        DATABASE_PATH: liveDatabasePath,
        NODE_ENV: 'production',
        PAYMENT_MODE: 'syncpay_live',
        SYNCPAY_CLIENT_ID: 'test-client-id',
        SYNCPAY_CLIENT_SECRET: 'test-client-secret',
        SYNCPAY_WEBHOOK_SECRET: 'test-webhook-secret'
    };
    const liveServer = spawn(process.execPath, ['server.js'], {
        cwd: root,
        env,
        stdio: ['ignore', 'ignore', 'pipe']
    });
    let liveServerError = '';
    liveServer.stderr.on('data', chunk => {
        liveServerError += chunk.toString();
    });

    try {
        let started = false;
        for (let attempt = 0; attempt < 100; attempt += 1) {
            if (liveServer.exitCode !== null) {
                throw new Error(`Live-mode test server exited: ${liveServerError}`);
            }
            try {
                const response = await fetch(localUrl);
                if (response.ok) {
                    started = true;
                    break;
                }
            } catch {
                await new Promise(resolve => setTimeout(resolve, 50));
            }
        }
        assert.ok(started, `Live-mode test server did not start: ${liveServerError}`);

        const registration = await fetch(localUrl + '/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Origin: expectedOrigin },
            body: JSON.stringify({
                email: 'regular@example.test',
                password: 'SecurePasswordForTest123!'
            })
        });
        assert.equal(registration.status, 201);
        const cookie = registration.headers.getSetCookie()
            .find(value => value.startsWith('fussionpay_session='))
            .split(';', 1)[0];

        const configResponse = await fetch(localUrl + '/api/payments/config', {
            headers: { Cookie: cookie }
        });
        assert.deepEqual(await configResponse.json(), {
            mode: 'disabled',
            livePayments: false,
            message: 'A operação de pagamentos está disponível somente para a equipe autorizada.'
        });

        const chargeList = await fetch(localUrl + '/api/charges', {
            headers: { Cookie: cookie }
        });
        assert.deepEqual(await chargeList.json(), { mode: 'disabled', charges: [] });

        const chargeResponse = await fetch(localUrl + '/api/charges', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Origin: expectedOrigin,
                Cookie: cookie
            },
            body: JSON.stringify({
                amountCents: 500,
                name: 'Cliente',
                email: 'buyer@example.test',
                document: '12345678901',
                phone: '11999998888',
                paymentMethod: 'pix',
                liveConsent: true
            })
        });
        assert.equal(chargeResponse.status, 403);
    } finally {
        if (liveServer.exitCode === null) {
            liveServer.kill();
            await Promise.race([
                once(liveServer, 'exit'),
                new Promise(resolve => setTimeout(resolve, 5000))
            ]);
        }
        for (const suffix of ['', '-shm', '-wal']) {
            const filePath = liveDatabasePath + suffix;
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        }
    }
});
