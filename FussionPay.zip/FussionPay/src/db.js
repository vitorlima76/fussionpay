const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

const dataDirectory = process.env.LOCALAPPDATA
    ? path.join(process.env.LOCALAPPDATA, 'FussionPay')
    : path.join(process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share'), 'FussionPay');
const databasePath = path.resolve(
    process.env.DATABASE_PATH || path.join(dataDirectory, 'fussionpay.sqlite')
);

fs.mkdirSync(path.dirname(databasePath), {
    recursive: true,
    mode: process.platform === 'win32' ? undefined : 0o700
});

const db = new DatabaseSync(databasePath);
if (process.platform !== 'win32') fs.chmodSync(databasePath, 0o600);
db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA journal_mode = WAL;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('customer', 'admin')),
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        expires_at INTEGER NOT NULL,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS sessions_user_id_idx ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS sessions_expires_at_idx ON sessions(expires_at);

    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
        action TEXT NOT NULL,
        ip_address TEXT,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON audit_logs(created_at);
    CREATE INDEX IF NOT EXISTS audit_logs_user_id_idx ON audit_logs(user_id);

    CREATE TABLE IF NOT EXISTS security_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        message TEXT NOT NULL,
        ip_address TEXT,
        acknowledged_at TEXT,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS security_events_created_at_idx ON security_events(created_at);
    CREATE INDEX IF NOT EXISTS security_events_unacknowledged_idx
        ON security_events(acknowledged_at, id);

    CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 160),
        email TEXT NOT NULL COLLATE NOCASE,
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        UNIQUE (owner_user_id, email)
    );
    CREATE INDEX IF NOT EXISTS customers_owner_created_idx
        ON customers(owner_user_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS charges (
        id TEXT PRIMARY KEY,
        owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
        amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
        currency TEXT NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
        payment_method TEXT NOT NULL CHECK (payment_method IN ('pix', 'boleto')),
        status TEXT NOT NULL DEFAULT 'sandbox_created' CHECK (status = 'sandbox_created'),
        description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 200),
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
    CREATE INDEX IF NOT EXISTS charges_owner_created_idx
        ON charges(owner_user_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS syncpay_charges (
        id TEXT PRIMARY KEY,
        owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
        amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
        currency TEXT NOT NULL DEFAULT 'BRL' CHECK (currency = 'BRL'),
        payment_method TEXT NOT NULL DEFAULT 'pix' CHECK (payment_method = 'pix'),
        status TEXT NOT NULL CHECK (status IN (
            'requesting', 'creation_unknown', 'pending', 'completed', 'failed',
            'refused', 'three_ds_failed', 'refunding', 'refunded', 'chargeback', 'med'
        )),
        description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 200),
        idempotency_key TEXT NOT NULL,
        provider_identifier TEXT UNIQUE,
        pix_code TEXT,
        status_updated_at TEXT,
        paid_at TEXT,
        expires_at TEXT,
        status_query_count INTEGER NOT NULL DEFAULT 0 CHECK (status_query_count BETWEEN 0 AND 5),
        created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        UNIQUE (owner_user_id, idempotency_key)
    );
    CREATE INDEX IF NOT EXISTS syncpay_charges_owner_created_idx
        ON syncpay_charges(owner_user_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS syncpay_webhook_events (
        event_id TEXT PRIMARY KEY,
        provider_identifier TEXT NOT NULL,
        status TEXT NOT NULL,
        occurred_at TEXT NOT NULL,
        received_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
`);

const syncPayChargeColumns = new Set(
    db.prepare('PRAGMA table_info(syncpay_charges)').all().map(column => column.name)
);
const syncPayChargeMigrations = [
    ['paid_at', 'ALTER TABLE syncpay_charges ADD COLUMN paid_at TEXT'],
    ['expires_at', 'ALTER TABLE syncpay_charges ADD COLUMN expires_at TEXT'],
    [
        'status_query_count',
        'ALTER TABLE syncpay_charges ADD COLUMN status_query_count INTEGER NOT NULL DEFAULT 0 CHECK (status_query_count BETWEEN 0 AND 5)'
    ]
];
for (const [column, migration] of syncPayChargeMigrations) {
    if (!syncPayChargeColumns.has(column)) db.exec(migration);
}

const statements = {
    findUserByEmail: db.prepare(`
        SELECT id, email, password_hash, role, is_active
        FROM users WHERE email = ?
    `),
    findUserById: db.prepare(`
        SELECT id, email, role, is_active FROM users WHERE id = ?
    `),
    insertUser: db.prepare(`
        INSERT INTO users (id, email, password_hash, role)
        VALUES (?, ?, ?, ?)
    `),
    updateAdminPassword: db.prepare(`
        UPDATE users
        SET password_hash = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ? AND role = 'admin' AND is_active = 1
    `),
    insertSession: db.prepare(`
        INSERT INTO sessions (id_hash, user_id, expires_at) VALUES (?, ?, ?)
    `),
    findSession: db.prepare(`
        SELECT users.id, users.email, users.role, users.is_active, sessions.expires_at
        FROM sessions
        JOIN users ON users.id = sessions.user_id
        WHERE sessions.id_hash = ?
    `),
    deleteSession: db.prepare('DELETE FROM sessions WHERE id_hash = ?'),
    deleteUserSessions: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
    deleteExpiredSessions: db.prepare('DELETE FROM sessions WHERE expires_at <= ?'),
    insertAudit: db.prepare(`
        INSERT INTO audit_logs (user_id, action, ip_address) VALUES (?, ?, ?)
    `),
    listAuditLogs: db.prepare(`
        SELECT audit_logs.id, audit_logs.action, audit_logs.ip_address,
            audit_logs.created_at, COALESCE(users.email, 'Sistema') AS actor
        FROM audit_logs
        LEFT JOIN users ON users.id = audit_logs.user_id
        ORDER BY audit_logs.id DESC
        LIMIT 50
    `),
    insertSecurityEvent: db.prepare(`
        INSERT INTO security_events (event_type, message, ip_address)
        VALUES (?, ?, ?)
    `),
    listSecurityEvents: db.prepare(`
        SELECT id, event_type, message, created_at
        FROM security_events
        WHERE acknowledged_at IS NULL
        ORDER BY id DESC LIMIT 50
    `),
    acknowledgeSecurityEvent: db.prepare(`
        UPDATE security_events
        SET acknowledged_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ? AND acknowledged_at IS NULL
    `),
    insertCustomer: db.prepare(`
        INSERT INTO customers (id, owner_user_id, name, email)
        VALUES (?, ?, ?, ?)
    `),
    insertCustomerIfMissing: db.prepare(`
        INSERT INTO customers (id, owner_user_id, name, email)
        VALUES (?, ?, ?, ?)
        ON CONFLICT (owner_user_id, email) DO NOTHING
    `),
    findCustomerByOwnerEmail: db.prepare(`
        SELECT id, name, email, created_at AS createdAt
        FROM customers
        WHERE owner_user_id = ? AND email = ?
    `),
    listCustomersByOwner: db.prepare(`
        SELECT customers.id, customers.name, customers.email,
            customers.created_at AS createdAt,
            COUNT(DISTINCT charges.id) + (
                SELECT COUNT(*) FROM syncpay_charges
                WHERE syncpay_charges.customer_id = customers.id
                    AND syncpay_charges.owner_user_id = customers.owner_user_id
            ) AS transactionCount
        FROM customers
        LEFT JOIN charges
            ON charges.customer_id = customers.id
            AND charges.owner_user_id = customers.owner_user_id
        WHERE customers.owner_user_id = ?
        GROUP BY customers.id
        ORDER BY customers.created_at DESC
        LIMIT 500
    `),
    insertSandboxCharge: db.prepare(`
        INSERT INTO charges (
            id, owner_user_id, customer_id, amount_cents,
            payment_method, description
        ) VALUES (?, ?, ?, ?, ?, ?)
    `),
    listSandboxChargesByOwner: db.prepare(`
        SELECT charges.id, charges.amount_cents AS amountCents,
            charges.currency, charges.payment_method AS paymentMethod,
            charges.status, charges.description, charges.created_at AS createdAt,
            customers.name AS customerName, customers.email AS customerEmail
        FROM charges
        JOIN customers ON customers.id = charges.customer_id
        WHERE charges.owner_user_id = ?
        ORDER BY charges.created_at DESC
        LIMIT 100
    `),
    findSandboxChargeByIdAndOwner: db.prepare(`
        SELECT charges.id, charges.amount_cents AS amountCents,
            charges.currency, charges.payment_method AS paymentMethod,
            charges.status, charges.description, charges.created_at AS createdAt,
            customers.name AS customerName, customers.email AS customerEmail
        FROM charges
        JOIN customers ON customers.id = charges.customer_id
        WHERE charges.owner_user_id = ? AND charges.id = ?
    `),
    listSyncPayChargesByOwner: db.prepare(`
        SELECT syncpay_charges.id, syncpay_charges.amount_cents AS amountCents,
            syncpay_charges.currency, syncpay_charges.payment_method AS paymentMethod,
            syncpay_charges.status, syncpay_charges.description,
            syncpay_charges.created_at AS createdAt,
            syncpay_charges.paid_at AS paidAt,
            syncpay_charges.expires_at AS expiresAt,
            syncpay_charges.status_query_count AS statusQueryCount,
            syncpay_charges.provider_identifier AS providerIdentifier,
            syncpay_charges.pix_code AS pixCode,
            'syncpay' AS provider,
            customers.name AS customerName, customers.email AS customerEmail
        FROM syncpay_charges
        JOIN customers ON customers.id = syncpay_charges.customer_id
        WHERE syncpay_charges.owner_user_id = ?
        ORDER BY syncpay_charges.created_at DESC
        LIMIT 100
    `),
    findSyncPayChargeByIdAndOwner: db.prepare(`
        SELECT syncpay_charges.id, syncpay_charges.amount_cents AS amountCents,
            syncpay_charges.currency, syncpay_charges.payment_method AS paymentMethod,
            syncpay_charges.status, syncpay_charges.description,
            syncpay_charges.created_at AS createdAt,
            syncpay_charges.paid_at AS paidAt,
            syncpay_charges.expires_at AS expiresAt,
            syncpay_charges.status_query_count AS statusQueryCount,
            syncpay_charges.provider_identifier AS providerIdentifier,
            syncpay_charges.pix_code AS pixCode,
            'syncpay' AS provider,
            customers.name AS customerName, customers.email AS customerEmail
        FROM syncpay_charges
        JOIN customers ON customers.id = syncpay_charges.customer_id
        WHERE syncpay_charges.owner_user_id = ? AND syncpay_charges.id = ?
    `),
    findSyncPayChargeByIdempotencyKeyAndOwner: db.prepare(`
        SELECT syncpay_charges.id, syncpay_charges.owner_user_id AS ownerUserId,
            syncpay_charges.customer_id AS customerId,
            syncpay_charges.amount_cents AS amountCents, syncpay_charges.status,
            syncpay_charges.description, syncpay_charges.created_at AS createdAt,
            syncpay_charges.status_query_count AS statusQueryCount,
            customers.name AS customerName, customers.email AS customerEmail
        FROM syncpay_charges
        JOIN customers ON customers.id = syncpay_charges.customer_id
        WHERE syncpay_charges.owner_user_id = ? AND syncpay_charges.idempotency_key = ?
    `),
    insertSyncPayCharge: db.prepare(`
        INSERT INTO syncpay_charges (
            id, owner_user_id, customer_id, amount_cents, status, description, idempotency_key
        ) VALUES (?, ?, ?, ?, 'requesting', ?, ?)
    `),
    setSyncPayChargeProviderResult: db.prepare(`
        UPDATE syncpay_charges
        SET provider_identifier = ?, pix_code = ?, status = 'pending',
            updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ? AND status = 'requesting'
    `),
    reserveSyncPayStatusQuery: db.prepare(`
        UPDATE syncpay_charges
        SET status_query_count = status_query_count + 1
        WHERE id = ? AND owner_user_id = ? AND status_query_count < 5
    `),
    setSyncPayChargeFailure: db.prepare(`
        UPDATE syncpay_charges
        SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ? AND status = 'requesting'
    `),
    insertSyncPayWebhookEvent: db.prepare(`
        INSERT OR IGNORE INTO syncpay_webhook_events (
            event_id, provider_identifier, status, occurred_at
        ) VALUES (?, ?, ?, ?)
    `),
    listSyncPayWebhookEventsByIdentifier: db.prepare(`
        SELECT status, occurred_at AS occurredAt
        FROM syncpay_webhook_events
        WHERE provider_identifier = ?
        ORDER BY occurred_at ASC
    `),
    findSyncPayChargeByProviderIdentifier: db.prepare(`
        SELECT id, amount_cents AS amountCents
        FROM syncpay_charges WHERE provider_identifier = ?
    `),
    findSyncPayChargeStatusByIdAndOwner: db.prepare(`
        SELECT id, amount_cents AS amountCents, status,
            provider_identifier AS providerIdentifier,
            status_query_count AS statusQueryCount,
            paid_at AS paidAt
        FROM syncpay_charges
        WHERE owner_user_id = ? AND id = ?
    `),
    updateSyncPayChargeStatus: db.prepare(`
        UPDATE syncpay_charges
        SET status = ?, status_updated_at = ?,
            paid_at = CASE WHEN ? = 'completed' THEN COALESCE(?, paid_at) ELSE paid_at END,
            updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE provider_identifier = ?
            AND (status_updated_at IS NULL OR status_updated_at <= ?)
    `)
};

module.exports = { db, statements, databasePath };
