const { db, statements } = require('./db');

function resetAdminPassword(email, passwordHash) {
    const admin = statements.findUserByEmail.get(email);
    if (!admin || admin.role !== 'admin' || admin.is_active !== 1) {
        throw new Error('Administrador ativo não encontrado. Nenhuma senha foi alterada.');
    }

    db.exec('BEGIN IMMEDIATE');
    try {
        const update = statements.updateAdminPassword.run(passwordHash, admin.id);
        if (update.changes !== 1) {
            throw new Error('Não foi possível redefinir a senha. Nenhuma alteração foi mantida.');
        }

        const revokedSessions = statements.deleteUserSessions.run(admin.id).changes;
        statements.insertAudit.run(null, 'admin.password_reset_cli', null);
        db.exec('COMMIT');

        return { revokedSessions };
    } catch (error) {
        db.exec('ROLLBACK');
        throw error;
    }
}

module.exports = { resetAdminPassword };
