const {
    randomBytes,
    scrypt: scryptCallback,
    timingSafeEqual,
    createHash
} = require('node:crypto');
const { promisify } = require('node:util');

const scrypt = promisify(scryptCallback);
const SCRYPT_COST = 16384;
const SCRYPT_BLOCK_SIZE = 8;
const SCRYPT_PARALLELIZATION = 1;
const KEY_LENGTH = 64;

async function hashPassword(password) {
    const salt = randomBytes(16);
    const hash = await scrypt(password, salt, KEY_LENGTH, {
        N: SCRYPT_COST,
        r: SCRYPT_BLOCK_SIZE,
        p: SCRYPT_PARALLELIZATION,
        maxmem: 64 * 1024 * 1024
    });

    return [
        'scrypt',
        SCRYPT_COST,
        SCRYPT_BLOCK_SIZE,
        SCRYPT_PARALLELIZATION,
        salt.toString('hex'),
        hash.toString('hex')
    ].join('$');
}

async function verifyPassword(password, encodedHash) {
    const parts = encodedHash.split('$');
    if (parts.length !== 6 || parts[0] !== 'scrypt') return false;

    const cost = Number(parts[1]);
    const blockSize = Number(parts[2]);
    const parallelization = Number(parts[3]);
    const salt = Buffer.from(parts[4], 'hex');
    const expected = Buffer.from(parts[5], 'hex');

    if (!Number.isSafeInteger(cost) || cost < 1024 || cost > 32768
        || !Number.isSafeInteger(blockSize) || blockSize < 1 || blockSize > 16
        || !Number.isSafeInteger(parallelization) || parallelization < 1 || parallelization > 4
        || salt.length !== 16 || expected.length !== KEY_LENGTH) {
        return false;
    }

    const actual = await scrypt(password, salt, expected.length, {
        N: cost,
        r: blockSize,
        p: parallelization,
        maxmem: 64 * 1024 * 1024
    });

    return timingSafeEqual(expected, actual);
}

function hashToken(token) {
    return createHash('sha256').update(token).digest('hex');
}

function createSessionToken() {
    return randomBytes(32).toString('base64url');
}

function isValidEmail(email) {
    return typeof email === 'string'
        && email.length <= 254
        && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

module.exports = {
    hashPassword,
    verifyPassword,
    hashToken,
    createSessionToken,
    isValidEmail
};
