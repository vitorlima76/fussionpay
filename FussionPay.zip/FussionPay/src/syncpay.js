const { createHmac, timingSafeEqual } = require('node:crypto');

const API_BASE_URL = 'https://api.syncpayments.com.br/api/partner/v1';
const TRANSACTION_API_URL = 'https://api.syncpayments.com.br/api/partner/v2';
const syncPayStatuses = new Set([
    'pending',
    'completed',
    'failed',
    'refused',
    'three_ds_failed',
    'refunding',
    'refunded',
    'chargeback',
    'med'
]);

class SyncPayApiError extends Error {
    constructor(message, { phase, statusCode = null, uncertain = false } = {}) {
        super(message);
        this.name = 'SyncPayApiError';
        this.phase = phase;
        this.statusCode = statusCode;
        this.uncertain = uncertain;
    }
}

function buildCashInPayload({ amountCents, description, name, document, email, phone }) {
    return {
        amount: Number((amountCents / 100).toFixed(2)),
        description,
        client: { name, document, email, phone }
    };
}

function verifySyncPaySignature(rawBody, signatureHeader, secret, now = Date.now()) {
    if (!Buffer.isBuffer(rawBody) || typeof signatureHeader !== 'string'
        || typeof secret !== 'string' || secret.length === 0) return false;

    const match = /^t=(\d+),v1=([a-f0-9]{64})$/i.exec(signatureHeader);
    if (!match) return false;

    const timestamp = Number(match[1]);
    if (!Number.isSafeInteger(timestamp) || Math.abs(Math.floor(now / 1000) - timestamp) > 300) {
        return false;
    }

    const expected = createHmac('sha256', secret)
        .update(`${match[1]}.`)
        .update(rawBody)
        .digest();
    const received = Buffer.from(match[2], 'hex');
    return received.length === expected.length && timingSafeEqual(received, expected);
}

function normalizeSyncPayStatus(status) {
    return syncPayStatuses.has(status) ? status : null;
}

class SyncPayClient {
    constructor({ clientId, clientSecret, fetchImpl = globalThis.fetch, now = Date.now }) {
        if (!clientId || !clientSecret) throw new Error('Credenciais SyncPay ausentes.');
        if (typeof fetchImpl !== 'function') throw new Error('Fetch não está disponível.');
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.fetchImpl = fetchImpl;
        this.now = now;
        this.accessToken = null;
        this.accessTokenExpiresAt = 0;
    }

    async getAccessToken(forceRefresh = false) {
        if (!forceRefresh && this.accessToken && this.now() < this.accessTokenExpiresAt) {
            return this.accessToken;
        }

        let response;
        try {
            response = await this.fetchImpl(`${API_BASE_URL}/auth-token`, {
                method: 'POST',
                headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    client_id: this.clientId,
                    client_secret: this.clientSecret
                }),
                signal: AbortSignal.timeout(15000)
            });
        } catch {
            throw new SyncPayApiError('Não foi possível autenticar na SyncPay.', { phase: 'auth' });
        }

        let body;
        try {
            body = await response.json();
        } catch {
            throw new SyncPayApiError('A SyncPay retornou uma resposta de autenticação inválida.', {
                phase: 'auth',
                statusCode: response.status
            });
        }

        const accessToken = body && body.access_token;
        const expiresIn = Number(body && body.expires_in);
        if (!response.ok || typeof accessToken !== 'string' || !accessToken
            || !Number.isFinite(expiresIn) || expiresIn <= 0) {
            throw new SyncPayApiError('A SyncPay recusou a autenticação.', {
                phase: 'auth',
                statusCode: response.status
            });
        }

        this.accessToken = accessToken;
        this.accessTokenExpiresAt = this.now() + Math.max(0, expiresIn - 60) * 1000;
        return this.accessToken;
    }

    async requestPartner(path, { method = 'GET', body, phase = 'partner' } = {}) {
        for (let attempt = 0; attempt < 2; attempt += 1) {
            const accessToken = await this.getAccessToken(attempt > 0);
            let response;
            try {
                response = await this.fetchImpl(`${API_BASE_URL}${path}`, {
                    method,
                    headers: {
                        Accept: 'application/json',
                        Authorization: `Bearer ${accessToken}`,
                        ...(body === undefined ? {} : { 'Content-Type': 'application/json' })
                    },
                    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
                    signal: AbortSignal.timeout(15000)
                });
            } catch {
                throw new SyncPayApiError('Não foi possível comunicar com a SyncPay.', { phase });
            }

            if (response.status === 401 && attempt === 0) {
                this.accessToken = null;
                this.accessTokenExpiresAt = 0;
                continue;
            }

            let responseBody;
            try {
                const text = await response.text();
                responseBody = text ? JSON.parse(text) : null;
            } catch {
                throw new SyncPayApiError('A SyncPay retornou uma resposta inválida.', {
                    phase,
                    statusCode: response.status
                });
            }

            if (!response.ok) {
                throw new SyncPayApiError('A SyncPay não aceitou a solicitação.', {
                    phase,
                    statusCode: response.status
                });
            }
            return responseBody;
        }

        throw new SyncPayApiError('A autenticação SyncPay expirou.', {
            phase,
            statusCode: 401
        });
    }

    getBalance() {
        return this.requestPartner('/balance', { phase: 'balance' });
    }

    getProfile() {
        return this.requestPartner('/profile', { phase: 'profile' });
    }

    listWebhooks({ search = '', perPage = 15 } = {}) {
        const query = new URLSearchParams({
            search,
            per_page: String(perPage)
        });
        return this.requestPartner(`/webhooks?${query}`, { phase: 'webhooks' });
    }

    createWebhook(payload) {
        return this.requestPartner('/webhooks', {
            method: 'POST',
            body: payload,
            phase: 'webhooks'
        });
    }

    updateWebhook(id, payload) {
        return this.requestPartner(`/webhooks/${encodeURIComponent(id)}`, {
            method: 'PUT',
            body: payload,
            phase: 'webhooks'
        });
    }

    deleteWebhook(id) {
        return this.requestPartner(`/webhooks/${encodeURIComponent(id)}`, {
            method: 'DELETE',
            phase: 'webhooks'
        });
    }

    async createCashIn(payload) {
        for (let attempt = 0; attempt < 2; attempt += 1) {
            const accessToken = await this.getAccessToken(attempt > 0);
            let response;
            try {
                response = await this.fetchImpl(`${API_BASE_URL}/cash-in`, {
                    method: 'POST',
                    headers: {
                        Accept: 'application/json',
                        Authorization: `Bearer ${accessToken}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload),
                    signal: AbortSignal.timeout(15000)
                });
            } catch {
                throw new SyncPayApiError('A resposta da SyncPay não foi recebida.', {
                    phase: 'cashin',
                    uncertain: true
                });
            }

            if (response.status === 401 && attempt === 0) {
                this.accessToken = null;
                this.accessTokenExpiresAt = 0;
                continue;
            }

            let body;
            try {
                body = await response.json();
            } catch {
                throw new SyncPayApiError('A SyncPay retornou uma resposta inválida para a cobrança.', {
                    phase: 'cashin',
                    statusCode: response.status,
                    uncertain: response.ok || response.status >= 500
                });
            }

            if (!response.ok) {
                throw new SyncPayApiError('A SyncPay não aceitou a solicitação de cobrança.', {
                    phase: 'cashin',
                    statusCode: response.status,
                    uncertain: response.status >= 500
                });
            }

            if (typeof body.identifier !== 'string' || !body.identifier
                || typeof body.pix_code !== 'string' || !body.pix_code) {
                throw new SyncPayApiError('A resposta da SyncPay não contém os dados esperados do Pix.', {
                    phase: 'cashin',
                    statusCode: response.status,
                    uncertain: true
                });
            }

            return { identifier: body.identifier, pixCode: body.pix_code };
        }

        throw new SyncPayApiError('A autenticação SyncPay expirou.', {
            phase: 'cashin',
            statusCode: 401
        });
    }

    async getTransaction(referenceId) {
        for (let attempt = 0; attempt < 2; attempt += 1) {
            const accessToken = await this.getAccessToken(attempt > 0);
            let response;
            try {
                response = await this.fetchImpl(
                    `${TRANSACTION_API_URL}/transactions/${encodeURIComponent(referenceId)}`,
                    {
                        method: 'GET',
                        headers: {
                            Accept: 'application/json',
                            Authorization: `Bearer ${accessToken}`
                        },
                        signal: AbortSignal.timeout(15000)
                    }
                );
            } catch {
                throw new SyncPayApiError('Não foi possível consultar a transação na SyncPay.', {
                    phase: 'transaction'
                });
            }

            if (response.status === 401 && attempt === 0) {
                this.accessToken = null;
                this.accessTokenExpiresAt = 0;
                continue;
            }

            let body;
            try {
                body = await response.json();
            } catch {
                throw new SyncPayApiError('A SyncPay retornou uma resposta inválida para a consulta.', {
                    phase: 'transaction',
                    statusCode: response.status
                });
            }

            if (!response.ok) {
                throw new SyncPayApiError('A SyncPay não aceitou a consulta da transação.', {
                    phase: 'transaction',
                    statusCode: response.status
                });
            }

            const transaction = body && body.data && body.data.transaction;
            const status = transaction && normalizeSyncPayStatus(transaction.status);
            if (!transaction || transaction.reference_id !== referenceId || !status
                || !Number.isFinite(transaction.amount) || transaction.amount < 0) {
                throw new SyncPayApiError('A resposta da SyncPay não contém os dados esperados da transação.', {
                    phase: 'transaction',
                    statusCode: response.status
                });
            }

            return {
                referenceId: transaction.reference_id,
                status,
                amount: transaction.amount,
                paidAt: typeof transaction.paid_at === 'string' ? transaction.paid_at : null,
                updatedAt: typeof transaction.updated_at === 'string'
                    ? transaction.updated_at
                    : null
            };
        }

        throw new SyncPayApiError('A autenticação SyncPay expirou.', {
            phase: 'transaction',
            statusCode: 401
        });
    }
}

module.exports = {
    SyncPayApiError,
    SyncPayClient,
    buildCashInPayload,
    normalizeSyncPayStatus,
    verifySyncPaySignature
};
