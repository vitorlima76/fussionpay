const { randomUUID } = require('node:crypto');
const readline = require('node:readline');
const { StringDecoder } = require('node:string_decoder');
const { statements, db } = require('../src/db');
const { hashPassword, isValidEmail } = require('../src/security');
const { resetAdminPassword } = require('../src/admin');

function question(prompt) {
    const terminal = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => terminal.question(prompt, answer => {
        terminal.close();
        resolve(answer.trim());
    }));
}

function hiddenQuestion(prompt) {
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
        throw new Error('Execute este comando em um terminal interativo para digitar a senha com segurança.');
    }

    return new Promise((resolve, reject) => {
        process.stdout.write(prompt);
        process.stdin.setRawMode(true);
        process.stdin.resume();
        let answer = '';
        const decoder = new StringDecoder('utf8');

        function onData(input) {
            const value = decoder.write(input);
            for (const character of value) {
                if (character === '\u0003') {
                    process.stdin.setRawMode(false);
                    process.stdin.pause();
                    process.stdin.removeListener('data', onData);
                    process.exitCode = 130;
                    reject(new Error('Operação cancelada.'));
                    return;
                }
                if (character === '\r' || character === '\n') {
                    process.stdin.setRawMode(false);
                    process.stdin.pause();
                    process.stdin.removeListener('data', onData);
                    process.stdout.write('\n');
                    resolve(answer);
                    return;
                }
                if (character === '\u0008' || character === '\u007f') {
                    answer = [...answer].slice(0, -1).join('');
                    continue;
                }
                if (character >= ' ') answer += character;
            }
        }

        process.stdin.on('data', onData);
    });
}

async function main() {
    const resettingPassword = process.argv[2] === '--reset';
    const emailArgument = process.argv[resettingPassword ? 3 : 2];
    const email = (emailArgument || await question('E-mail do administrador: ')).toLowerCase();
    if (!isValidEmail(email)) throw new Error('Informe um endereço de e-mail válido.');

    const existingUser = statements.findUserByEmail.get(email);
    if (resettingPassword
        && (!existingUser || existingUser.role !== 'admin' || existingUser.is_active !== 1)) {
        throw new Error('Administrador ativo não encontrado. Nenhuma senha foi alterada.');
    }
    if (!resettingPassword && existingUser) {
        throw new Error('Já existe uma conta com esse e-mail.');
    }

    const password = await hiddenQuestion('Senha (mínimo 12 caracteres): ');
    const confirmation = await hiddenQuestion('Confirme a senha: ');
    if (password.length < 12 || password.length > 128) {
        throw new Error('A senha deve ter entre 12 e 128 caracteres.');
    }
    if (password !== confirmation) throw new Error('As senhas não conferem.');

    const passwordHash = await hashPassword(password);
    if (resettingPassword) {
        resetAdminPassword(email, passwordHash);
        console.log('Senha redefinida com sucesso. As sessões anteriores foram revogadas.');
    } else {
        statements.insertUser.run(randomUUID(), email, passwordHash, 'admin');
        console.log(`Administrador ${email} criado. Guarde a senha em um gerenciador seguro.`);
    }
}

main()
    .catch(error => {
        console.error(error.message);
        process.exitCode = 1;
    })
    .finally(() => db.close());
